<?php
session_start();
include 'db_connect.php';

// Allow only admins
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$system_daily_limit = 20;
$today = date('Y-m-d');

// Handle filters
$status_filter = $_GET['status'] ?? '';
$from_date = $_GET['from'] ?? '';
$to_date = $_GET['to'] ?? '';

// Base query
$query = "
  SELECT 
    b.booking_id, b.booking_date, b.status, b.duration,
    up.fullname AS parent_name, us.fullname AS sitter_name,
    s.hourly_rate, p.num_children
  FROM bookings b
  JOIN parents p ON b.parent_id = p.parent_id
  JOIN sitters s ON b.sitter_id = s.sitter_id
  JOIN users up ON p.user_id = up.id
  JOIN users us ON s.user_id = us.id
  WHERE 1
";

// Apply filters dynamically
$params = [];
$types = '';

if ($status_filter) {
    $query .= " AND b.status = ?";
    $types .= 's';
    $params[] = $status_filter;
}

if ($from_date && $to_date) {
    $query .= " AND DATE(b.booking_date) BETWEEN ? AND ?";
    $types .= 'ss';
    $params[] = $from_date;
    $params[] = $to_date;
}

$query .= " ORDER BY b.booking_date DESC";

$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

// Fetch today's total bookings
$stmt_today = $conn->prepare("SELECT COUNT(*) AS total FROM bookings WHERE DATE(booking_date) = ?");
$stmt_today->bind_param('s', $today);
$stmt_today->execute();
$today_total = $stmt_today->get_result()->fetch_assoc()['total'];

// Payment calculation
function calcPayment($rate, $numChildren, $duration) {
    if ($numChildren == 1) $base = $rate;
    elseif ($numChildren == 2) $base = $rate * 1.5;
    else $base = $rate * 2;
    return $base * $duration;
}

// CSV Export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment;filename="bookings_report.csv"');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['Booking ID', 'Parent', 'Sitter', 'Date', 'Status', 'Duration (hrs)', 'Total Payment (Ksh)']);
    while ($row = $result->fetch_assoc()) {
        $payment = calcPayment($row['hourly_rate'], $row['num_children'], $row['duration']);
        fputcsv($output, [
            $row['booking_id'],
            $row['parent_name'],
            $row['sitter_name'],
            $row['booking_date'],
            ucfirst($row['status']),
            $row['duration'],
            number_format($payment, 2)
        ]);
    }
    fclose($output);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin | Bookings Overview</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      font-family: "Poppins", sans-serif;
      background: #f8f8f8;
      margin: 0;
    }
    header {
      background-color: #f68b1e;
      color: #fff;
      padding: 15px 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    header h2 { margin: 0; }
    nav a {
      color: white;
      text-decoration: none;
      margin-left: 15px;
    }
    .container {
      width: 90%;
      max-width: 1200px;
      margin: 40px auto;
      background: #fff;
      padding: 25px;
      border-radius: 12px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    h2 {
      color: #f68b1e;
      text-align: center;
      font-size: 22px;
      margin-bottom: 20px;
    }
    .stats {
      display: flex;
      justify-content: space-between;
      background: #fff8f0;
      padding: 20px;
      border-radius: 10px;
      margin-bottom: 25px;
      border: 1px solid #f68b1e30;
    }
    .stat-box {
      text-align: center;
      flex: 1;
    }
    .stat-box h3 {
      color: #f68b1e;
      margin-bottom: 8px;
    }
    .highlight-number {
      font-size: 22px;
      font-weight: bold;
    }
    form {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 20px;
    }
    select, input[type=date] {
      padding: 8px;
      border: 1px solid #ddd;
      border-radius: 6px;
    }
    .btn {
      background-color: #f68b1e;
      color: white;
      border: none;
      padding: 8px 15px;
      border-radius: 6px;
      cursor: pointer;
      text-decoration: none;
    }
    .btn:hover { background-color: #e67e1e; }
    table {
      width: 100%;
      border-collapse: collapse;
    }
    th, td {
      padding: 10px 12px;
      border: 1px solid #ddd;
      font-size: 14px;
      text-align: center;
    }
    th {
      background-color: #f68b1e;
      color: white;
    }
    tr:nth-child(even) { background-color: #f9f9f9; }
    footer {
      background-color: #f68b1e;
      color: #fff;
      text-align: center;
      padding: 12px;
      margin-top: 40px;
      font-size: 13px;
    }
  </style>
</head>
<body>

<header>
  <h2>🧡 Admin Dashboard | Bookings</h2>
  <nav>
    <a href="Admin_Dashboard.php">Dashboard</a>
    <a href="logout.php">Logout</a>
  </nav>
</header>

<div class="container">
  <h2>Bookings Overview</h2>

  <div class="stats">
    <div class="stat-box">
      <h3>Today’s Bookings</h3>
      <p class="highlight-number"><?= $today_total ?></p>
    </div>
    <div class="stat-box">
      <h3>System Daily Limit</h3>
      <p class="highlight-number"><?= $system_daily_limit ?></p>
    </div>
    <div class="stat-box">
      <h3>Remaining Slots</h3>
      <p class="highlight-number"><?= max(0, $system_daily_limit - $today_total) ?></p>
    </div>
  </div>

  <!-- Filter Form -->
  <form method="GET">
    <label>Status:</label>
    <select name="status">
      <option value="">All</option>
      <option value="pending" <?= $status_filter === 'pending' ? 'selected' : '' ?>>Pending</option>
      <option value="completed" <?= $status_filter === 'completed' ? 'selected' : '' ?>>Completed</option>
      <option value="cancelled" <?= $status_filter === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
    </select>

    <label>From:</label>
    <input type="date" name="from" value="<?= htmlspecialchars($from_date) ?>">

    <label>To:</label>
    <input type="date" name="to" value="<?= htmlspecialchars($to_date) ?>">

    <button type="submit" class="btn">Filter</button>
    <a href="?export=csv" class="btn">Export CSV</a>
  </form>

  <table>
    <tr>
      <th>ID</th>
      <th>Parent</th>
      <th>Sitter</th>
      <th>Date</th>
      <th>Status</th>
      <th>Duration (hrs)</th>
      <th>Total Payment (Ksh)</th>
    </tr>
    <?php if ($result->num_rows > 0): ?>
      <?php while ($row = $result->fetch_assoc()): 
        $payment = calcPayment($row['hourly_rate'], $row['num_children'], $row['duration']);
        $statusColor = $row['status'] === 'completed' ? 'green' :
                       ($row['status'] === 'cancelled' ? 'red' : '#f68b1e');
      ?>
      <tr>
        <td><?= $row['booking_id'] ?></td>
        <td><?= htmlspecialchars($row['parent_name']) ?></td>
        <td><?= htmlspecialchars($row['sitter_name']) ?></td>
        <td><?= $row['booking_date'] ?></td>
        <td style="color:<?= $statusColor ?>;"><strong><?= ucfirst($row['status']) ?></strong></td>
        <td><?= $row['duration'] ?></td>
        <td><strong><?= number_format($payment, 2) ?></strong></td>
      </tr>
      <?php endwhile; ?>
    <?php else: ?>
      <tr><td colspan="7" style="text-align:center;">No bookings found</td></tr>
    <?php endif; ?>
  </table>
</div>

<footer>
  <p>© <?= date("Y") ?> ChaguaSitter. All rights reserved.</p>
</footer>
<script src="script.js"></script>
</body>
</html>
