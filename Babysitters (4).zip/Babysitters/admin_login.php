<?php
session_start();
include('db_connect.php');
include('config.php'); // contains $admin_email and $admin_password

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // --- Admin login verification ---
    if ($email === $admin_email && $password === $admin_password) {
        $_SESSION['user_id'] = 'admin';
        $_SESSION['user_type'] = 'admin'; // ✅ matches Admin_Dashboard.php
        header('Location: admin_dashboard.php');
        exit();
    } else {
        $error = "❌ Invalid admin credentials!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login | ChaguaSitter</title>
<style>
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  font-family: 'Poppins', sans-serif;
}
body {
  background: url('https://www.shutterstock.com/shutterstock/photos/2640547397/display_1500/stock-photo-african-daycare-centre-with-caregiver-2640547397.jpg') no-repeat center center/cover;
  background-attachment: fixed;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
}
.login-container {
  background: rgba(255, 255, 255, 0.92);
  width: 380px;
  border-radius: 15px;
  box-shadow: 0 6px 25px rgba(0,0,0,0.25);
  padding: 40px 30px;
  text-align: center;
  backdrop-filter: blur(8px);
}
.login-container h2 {
  margin-bottom: 25px;
  color: #e67e22;
  font-size: 1.9em;
}
form input[type="email"],
form input[type="password"] {
  width: 100%;
  padding: 12px 15px;
  margin-bottom: 15px;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 1em;
}
form button {
  width: 100%;
  background: #e67e22;
  color: white;
  padding: 12px;
  border: none;
  border-radius: 8px;
  font-size: 1em;
  font-weight: bold;
  cursor: pointer;
  transition: 0.3s;
}
form button:hover {
  background: #cf6f1b;
}
.error {
  color: red;
  font-size: 0.9em;
  margin-bottom: 15px;
}
a.back-home {
  display: inline-block;
  margin-top: 15px;
  color: #e67e22;
  text-decoration: none;
  font-weight: 600;
}
a.back-home:hover {
  text-decoration: underline;
}
</style>
</head>
<body>

<div class="login-container">
  <h2>Admin Login</h2>
  <?php if ($error): ?>
      <p class="error"><?php echo htmlspecialchars($error); ?></p>
  <?php endif; ?>

  <form method="POST" action="">
      <input type="email" name="email" placeholder="Admin Email" required>
      <input type="password" name="password" placeholder="Password" required>
      <button type="submit">Login</button>
  </form>

  <a href="index.php" class="back-home">← Back to Home</a>
</div>
<script src="script.js"></script>
</body>
</html>
