<?php
session_start();
include 'db_connect.php';

// Only admin can access this
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("Unauthorized");
}

$type = $_GET['type'] ?? '';
$id   = intval($_GET['id']);

if (!in_array($type, ['parent', 'sitter'])) {
    die("Invalid request.");
}

// Backup admin session
if (!isset($_SESSION['admin_backup'])) {
    $_SESSION['admin_backup'] = $_SESSION;
}

// Impersonate user
if ($type === 'parent') {
    $query = $conn->query("SELECT p.*, u.fullname, u.email 
                           FROM parents p 
                           JOIN users u ON p.user_id = u.id
                           WHERE p.parent_id = $id");
    $user = $query->fetch_assoc();
    if (!$user) die("Parent not found.");

    // Set session as parent
    $_SESSION['role']       = 'parent';
    $_SESSION['parent_id']  = $user['parent_id'];
    $_SESSION['user_id']    = $user['user_id'];

} elseif ($type === 'sitter') {
    $query = $conn->query("SELECT s.*, u.fullname, u.email 
                           FROM sitters s 
                           JOIN users u ON s.user_id = u.id
                           WHERE s.sitter_id = $id");
    $user = $query->fetch_assoc();
    if (!$user) die("Sitter not found.");

    // Set session as sitter
    $_SESSION['role']       = 'sitter';
    $_SESSION['sitter_id']  = $user['sitter_id'];
    $_SESSION['user_id']    = $user['user_id'];
}

// Mark admin is impersonating
$_SESSION['admin_impersonating'] = true;

// Redirect directly to the user's dashboard
if ($type === 'parent') {
    header("Location: parent_Dashboard.php");
} else {
    header("Location: sitters_Dashboard.php");
}
exit;
