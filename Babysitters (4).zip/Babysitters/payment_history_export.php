<?php
session_start();
include('db_connect.php');
if(!isset($_SESSION['user_id'])){
    die("Unauthorized");
}

$user_id = $_SESSION['user_id'];
$role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
$type = isset($_GET['type']) ? $_GET['type'] : 'pdf';
$bookingFilter = isset($_GET['booking_id']) ? $_GET['booking_id'] : '';
$statusFilter = isset($_GET['status']) ? $_GET['status'] : '';

// --- Fetch live payments based on filters ---
$where = [];
$params = [];
$types = '';

if($role === "parent"){
    $where[] = "parent_id=?";
    $params[] = $user_id;
    $types .= "i";
} elseif($role === "sitter"){
    $where[] = "sitter_id=?";
    $params[] = $user_id;
    $types .= "i";
}

if($bookingFilter !== ""){
    $where[] = "booking_id=?";
    $params[] = $bookingFilter;
    $types .= "i";
}

if($statusFilter !== ""){
    $where[] = "status=?";
    $params[] = $statusFilter;
    $types .= "s";
}

$sql = "SELECT * FROM payments";
if(count($where) > 0){
    $sql .= " WHERE ".implode(" AND ", $where);
}
$sql .= " ORDER BY created_at DESC";

$stmt = $conn->prepare($sql);
if($stmt === false){
    die("Prepare failed: " . $conn->error);
}
if(count($params) > 0){
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

$payments = [];
while($row = $result->fetch_assoc()){
    $payments[] = $row;
}

// --- Export PDF ---
if($type === "pdf"){
    require_once('tcpdf_min/tcpdf.php'); // Make sure TCPDF is installed
    $pdf = new TCPDF();
    $pdf->AddPage();

    $html = '<h2>Payment History</h2><table border="1" cellpadding="4">
    <tr>
        <th>ID</th>
        <th>Booking</th>
        <th>Amount</th>
        <th>Method</th>
        <th>Status</th>
        <th>Transaction</th>
        <th>Date</th>
    </tr>';

    foreach($payments as $p){
        $html .= '<tr>
            <td>'.htmlspecialchars($p['payment_id']).'</td>
            <td>'.htmlspecialchars($p['booking_id']).'</td>
            <td>'.number_format($p['amount'],2).'</td>
            <td>'.htmlspecialchars($p['payment_method']).'</td>
            <td>'.htmlspecialchars($p['status']).'</td>
            <td>'.htmlspecialchars($p['transaction_code']).'</td>
            <td>'.htmlspecialchars($p['created_at']).'</td>
        </tr>';
    }

    $html .= '</table>';
    $pdf->writeHTML($html, true, false, true, false, '');
    $pdf->Output("payment_history.pdf", "I");

// --- Export Excel ---
} elseif($type === "excel"){
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=payment_history.xls");
    echo "<table border='1'><tr>
        <th>ID</th>
        <th>Booking</th>
        <th>Amount</th>
        <th>Method</th>
        <th>Status</th>
        <th>Transaction</th>
        <th>Date</th>
    </tr>";
    foreach($payments as $p){
        echo "<tr>
            <td>".htmlspecialchars($p['payment_id'])."</td>
            <td>".htmlspecialchars($p['booking_id'])."</td>
            <td>".number_format($p['amount'],2)."</td>
            <td>".htmlspecialchars($p['payment_method'])."</td>
            <td>".htmlspecialchars($p['status'])."</td>
            <td>".htmlspecialchars($p['transaction_code'])."</td>
            <td>".htmlspecialchars($p['created_at'])."</td>
        </tr>";
    }
    echo "</table>";
}
?>
