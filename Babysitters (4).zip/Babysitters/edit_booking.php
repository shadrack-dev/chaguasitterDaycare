<?php
session_start();
include 'db_connect.php';

// Ensure sitter is logged in
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'sitter') {
    header('Location: sitter_auth.php');
    exit();
}

$sitter_id = $_SESSION['user_id'];

// Get booking ID from query string
$booking_id = intval($_GET['id'] ?? 0);
if ($booking_id <= 0) {
    echo "<script>alert('Invalid booking.'); window.location='view_bookings.php';</script>";
    exit();
}

// Fetch booking data
$query = "SELECT * FROM bookings WHERE booking_id = ? AND sitter_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('ii', $booking_id, $sitter_id);
$stmt->execute();
$result = $stmt->get_result();
$booking = $result->fetch_assoc();
$stmt->close();

if (!$booking) {
    echo "<script>alert('Booking not found.'); window.location='view_bookings.php';</script>";
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $booking_date = $_POST['booking_date'] ?? $booking['booking_date'];
    $start_time = $_POST['start_time'] ?? $booking['start_time'];
    $end_time = $_POST['end_time'] ?? $booking['end_time'];
    $status = $_POST['status'] ?? $booking['status'];

    $update = "UPDATE bookings SET booking_date=?, start_time=?, end_time=?, status=? WHERE booking_id=? AND sitter_id=?";
    $stmt = $conn->prepare($update);
    $stmt->bind_param('ssssii', $booking_date, $start_time, $end_time, $status, $booking_id, $sitter_id);
    if ($stmt->execute()) {
        echo "<script>alert('Booking updated successfully!'); window.location='view_bookings.php';</script>";
    } else {
        echo "<script>alert('Error updating booking.'); window.location='view_bookings.php';</script>";
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Booking | ChaguaSitter</title>
<style>
body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background-color: #f0f2f5;
}

/* Wrapper */
.wrapper {
    display: flex;
    min-height: 100vh;
}

/* Sidebar */
.sidebar {
    width: 220px;
    background-color: #ff6f00;
    color: white;
    display: flex;
    flex-direction: column;
    padding-top: 30px;
}
.sidebar h2 {
    text-align: center;
    margin-bottom: 30px;
    font-size: 22px;
}
.sidebar a {
    color: white;
    text-decoration: none;
    padding: 15px 20px;
    display: block;
    transition: 0.3s;
}
.sidebar a:hover, .sidebar a.active {
    background-color: #e65c00;
}

/* Main content */
.main-content {
    flex: 1;
    padding: 30px 40px;
}

/* Top bar */
.top-bar {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    margin-bottom: 20px;
}
.top-bar a.logout-btn {
    background-color: #444;
    color: white;
    padding: 8px 15px;
    border-radius: 6px;
    text-decoration: none;
    font-weight: bold;
    transition: background 0.3s;
}
.top-bar a.logout-btn:hover { background-color: #333; }

/* Form Card */
.form-card {
    background: #fff;
    padding: 25px 30px;
    border-radius: 12px;
    box-shadow: 0 6px 18px rgba(0,0,0,0.15);
}
.form-card h2 {
    color: #ff6f00;
    margin-bottom: 20px;
    border-bottom: 2px solid #ff6f00;
    padding-bottom: 5px;
    text-align: center;
}

/* Form Elements */
label {
    display: block;
    margin-bottom: 6px;
    font-weight: 600;
    color: #555;
}
input, select {
    width: 100%;
    padding: 10px 12px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 14px;
}
input:focus, select:focus { border-color: #ff6f00; }

/* Buttons */
.btn {
    display: inline-block;
    background-color: #ff6f00;
    color: white;
    padding: 10px 22px;
    border-radius: 6px;
    text-decoration: none;
    font-weight: bold;
    margin-top: 10px;
    margin-right: 10px;
    transition: 0.3s;
}
.btn:hover { background-color: #e65c00; }
.btn.secondary { background-color: #555; }
.btn.secondary:hover { background-color: #333; }
.btn-container { text-align: center; margin-top: 20px; }

/* Footer */
footer {
    text-align: center;
    padding: 20px;
    background-color: #333;
    color: white;
    margin-top: 40px;
    font-size: 14px;
}

/* Responsive */
@media (max-width: 768px) {
    .wrapper { flex-direction: column; }
    .sidebar { width: 100%; flex-direction: row; overflow-x: auto; }
    .sidebar a { flex: 1; text-align: center; padding: 12px; }
    .top-bar { justify-content: center; margin-bottom: 10px; }
}
</style>
</head>
<body>

<div class="wrapper">
    <!-- Sidebar -->
    <div class="sidebar">
        <h2>ChaguaSitter</h2>
        <a href="sitters_Dashboard.php">Dashboard</a>
        <a href="edit_profile.php">Edit Profile</a>
        <a href="view_bookings.php" class="active">View Bookings</a>
    </div>

    <!-- Main content -->
    <div class="main-content">
        <div class="top-bar">
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>

        <div class="form-card">
            <h2>Edit Booking</h2>
            <form method="POST" action="">
                <label for="booking_date">Booking Date</label>
                <input type="date" name="booking_date" id="booking_date" value="<?php echo htmlspecialchars($booking['booking_date']); ?>" required>

                <label for="start_time">Start Time</label>
                <input type="time" name="start_time" id="start_time" value="<?php echo htmlspecialchars($booking['start_time']); ?>" required>

                <label for="end_time">End Time</label>
                <input type="time" name="end_time" id="end_time" value="<?php echo htmlspecialchars($booking['end_time']); ?>" required>

                <label for="status">Status</label>
                <select name="status" id="status" required>
                    <option value="pending" <?php echo ($booking['status']=='pending')?'selected':''; ?>>Pending</option>
                    <option value="confirmed" <?php echo ($booking['status']=='confirmed')?'selected':''; ?>>Confirmed</option>
                    <option value="cancelled" <?php echo ($booking['status']=='cancelled')?'selected':''; ?>>Cancelled</option>
                </select>

                <div class="btn-container">
                    <button type="submit" class="btn">Update Booking</button>
                    <a href="view_bookings.php" class="btn secondary">Back</a>
                </div>
            </form>
        </div>
    </div>
</div>

<footer>&copy; <?php echo date('Y'); ?> ChaguaSitter. All rights reserved.</footer>
<script src="script.js"></script>
</body>
</html>
