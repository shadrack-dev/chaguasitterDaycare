<?php
session_start();
include 'db_connect.php';
include 'config.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $role = $_POST['role'];

    // --- Validation ---
    if (empty($fullname) || empty($email) || empty($password) || empty($confirm_password) || empty($role) || empty($phone)) {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif (!preg_match('/^[0-9]{10,15}$/', $phone)) {
        $error = "Enter a valid phone number (10–15 digits).";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        // Check if email already exists
        $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $error = "Email is already registered.";
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Insert new user
            $stmt = $conn->prepare("INSERT INTO users (fullname, email, phone, password, role) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $fullname, $email, $phone, $hashedPassword, $role);

            if ($stmt->execute()) {
                $success = "Registration successful! Please <a href='login.php'>login here</a>.";
            } else {
                $error = "Registration failed. Please try again.";
            }
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register | ChaguaSitter</title>
<style>
/* =========================
   Global Reset & Fonts
========================= */
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: 'Poppins', sans-serif;
}

body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background: url('https://www.shutterstock.com/shutterstock/photos/2640547397/display_1500/stock-photo-african-daycare-centre-with-caregiver-2640547397.jpg') no-repeat center center/cover;
}
/* =========================
   Card Container
========================= */
.register-container {
    background: #fff;
    border-radius: 16px;
    padding: 35px 30px;
    width: 360px;
    max-width: 90%;
    box-shadow: 0 8px 20px rgba(0,0,0,0.2);
    text-align: center;
    transition: transform 0.3s;
}
.register-container:hover {
    transform: translateY(-3px);
}

/* =========================
   Heading
========================= */
h2 {
    color: rgba(236, 119, 9, 1);
    margin-bottom: 20px;
    font-size: 24px;
    font-weight: 600;
}

/* =========================
   Inputs & Select
========================= */
input, select {
    width: 100%;
    padding: 12px;
    margin: 10px 0;
    border-radius: 8px;
    border: 1px solid #ccc;
    font-size: 14px;
    transition: all 0.3s;
}
input:focus, select:focus {
    border-color: rgba(248, 118, 11, 1);
    box-shadow: 0 0 5px rgba(28,200,138,0.4);
    outline: none;
}

/* =========================
   Password Toggle
========================= */
.password-container {
    position: relative;
}
.toggle-password {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    color: #777;
    user-select: none;
}

/* =========================
   Button
========================= */
button {
    width: 100%;
    padding: 14px;
    background: rgba(247, 136, 9, 1);
    color: #fff;
    font-size: 16px;
    font-weight: 600;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s;
}
button:hover {
    background: #17a673;
}

/* =========================
   Messages
========================= */
.message {
    margin-bottom: 15px;
    font-weight: 500;
}
.message.success {
    color: rgba(236, 132, 12, 1);
}
.message.error {
    color: #d32f2f;
}

/* =========================
   Login Link
========================= */
.login-link {
    margin-top: 15px;
    font-size: 14px;
    color: #555;
}
.login-link a {
    color: #df8807ff;
    font-weight: 600;
    text-decoration: none;
}
.login-link a:hover {
    text-decoration: underline;
}

/* =========================
   Responsive
========================= */
@media(max-width: 400px){
    .register-container {
        padding: 25px 20px;
        width: 90%;
    }
}
</style>
</head>
<body>

<div class="register-container">
    <h2>Create Your Account</h2>

    <?php if ($error): ?><div class="message error"><?= $error ?></div><?php endif; ?>
    <?php if ($success): ?><div class="message success"><?= $success ?></div><?php endif; ?>

    <form method="POST" action="">
        <input type="text" name="fullname" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email Address" required>
        <input type="text" name="phone" placeholder="Phone Number" required>

        <div class="password-container">
            <input type="password" name="password" id="password" placeholder="Password" required minlength="6">
            <span class="toggle-password" onclick="togglePassword('password', this)">👁️</span>
        </div>

        <div class="password-container">
            <input type="password" name="confirm_password" id="confirm_password" placeholder="Confirm Password" required minlength="6">
            <span class="toggle-password" onclick="togglePassword('confirm_password', this)">👁️</span>
        </div>

        <select name="role" required>
            <option value="">Select Role</option>
            <option value="parent">Parent</option>
            <option value="sitter">Sitter</option>
        </select>

        <button type="submit">Register</button>
    </form>

    <div class="login-link">
        Already have an account? <a href="login.php">Login here</a>
    </div>
</div>

<script>
function togglePassword(fieldId, icon){
    const input = document.getElementById(fieldId);
    if(input.type === "password"){
        input.type = "text";
        icon.textContent = "🙈";
    } else {
        input.type = "password";
        icon.textContent = "👁️";
    }
}
</script>
<script src="script.js"></script>
</body>
</html>
