<?php
session_start();
include 'db_connect.php';

// Fetch all bookings with joined user details
$query = "
  SELECT 
    b.booking_id,
    b.booking_date,
    b.status,
    up.fullname AS parent_name,
    us.fullname AS sitter_name
  FROM bookings b
  LEFT JOIN parents p ON b.parent_id = p.parent_id
  LEFT JOIN users up ON p.user_id = up.id
  LEFT JOIN sitters s ON b.sitter_id = s.sitter_id
  LEFT JOIN users us ON s.user_id = us.id
  ORDER BY b.booking_date DESC
";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Bookings | ChaguaSitter</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      font-family: "Poppins", sans-serif;
      background: #f5f5f5;
      margin: 0;
    }

    header {
      background-color: #f68b1e;
      color: #fff;
      padding: 15px 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    header h2 {
      margin: 0;
      font-weight: 600;
    }

    .container {
      width: 95%;
      max-width: 1100px;
      margin: 50px auto;
      background: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #f68b1e;
      margin-bottom: 30px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    th, td {
      padding: 12px;
      border: 1px solid #ddd;
      text-align: left;
    }

    th {
      background-color: #f68b1e;
      color: white;
    }

    tr:nth-child(even) {
      background-color: #f9f9f9;
    }

    tr:hover {
      background-color: #ffe8d6;
    }

    .add-booking {
      display: flex;
      justify-content: flex-end;
      margin-bottom: 15px;
    }

    .btn {
      background-color: #f68b1e;
      color: white;
      padding: 8px 15px;
      text-decoration: none;
      border-radius: 5px;
      font-weight: 600;
      transition: background 0.3s ease;
    }

    .btn:hover {
      background-color: #e67e1e;
    }

    .no-data {
      text-align: center;
      color: #888;
      padding: 20px 0;
    }

    footer {
      background-color: #f68b1e;
      color: #fff;
      text-align: center;
      padding: 15px;
      margin-top: 50px;
      font-size: 14px;
    }

    .back-link {
      display: inline-block;
      margin-top: 20px;
      text-decoration: none;
      color: #f68b1e;
      font-weight: 600;
    }

    .back-link:hover {
      color: #e67e1e;
    }
  </style>
</head>
<body>

<header>
  <h2>🧡 ChaguaSitter | View Bookings</h2>
  <nav>
    <a href="index.php" style="color:white; text-decoration:none; margin-left:20px;">Home</a>
    <a href="add_booking.php" style="color:white; text-decoration:none; margin-left:20px;">Add Booking</a>
  </nav>
</header>

<div class="container">
  <h2>All Bookings</h2>

  <div class="add-booking">
    <a href="add_booking.php" class="btn">+ Add New Booking</a>
  </div>

  <table>
    <tr>
      <th>ID</th>
      <th>Parent Name</th>
      <th>Sitter Name</th>
      <th>Booking Date</th>
      <th>Status</th>
    </tr>
    <?php
    if (mysqli_num_rows($result) > 0) {
      while ($row = mysqli_fetch_assoc($result)) {
        echo "
          <tr>
            <td>{$row['booking_id']}</td>
            <td>{$row['parent_name']}</td>
            <td>{$row['sitter_name']}</td>
            <td>{$row['booking_date']}</td>
            <td style='font-weight:600; color:" . 
              ($row['status'] == 'completed' ? 'green' : 
              ($row['status'] == 'cancelled' ? 'red' : '#f68b1e')) . "'>
              {$row['status']}
            </td>
          </tr>
        ";
      }
    } else {
      echo "<tr><td colspan='5' class='no-data'>No bookings found</td></tr>";
    }
    ?>
  </table>

  <a href="index.php" class="back-link">← Back to Dashboard</a>
</div>

<footer>
  <p>© <?= date("Y") ?> ChaguaSitter. Designed with ❤️ by the ChaguaSitter Team.</p>
</footer>

<script src="script.js"></script>
</body>
</html>
