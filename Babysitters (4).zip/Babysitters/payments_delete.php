<?php
header("Content-Type: application/json");
include "db_connect.php";
include "config.php";
include "jwt_functions.php";

$id = $_GET['id'];

$sql = "DELETE FROM payments WHERE payment_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Payment deleted"]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to delete"]);
}
?>
