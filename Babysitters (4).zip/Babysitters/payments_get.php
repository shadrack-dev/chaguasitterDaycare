<?php
header("Content-Type: application/json");
include "db_connect.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = $conn->query("SELECT * FROM payments WHERE payment_id = $id");

    echo json_encode($query->fetch_assoc());
} else {
    $result = $conn->query("SELECT * FROM payments ORDER BY payment_id DESC");

    $payments = [];
    while ($row = $result->fetch_assoc()) {
        $payments[] = $row;
    }

    echo json_encode($payments);
}
?>
