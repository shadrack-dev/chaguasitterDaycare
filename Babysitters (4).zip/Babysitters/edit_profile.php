<?php
session_start();
include 'db_connect.php';

// Ensure sitter is logged in
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'sitter') {
    header('Location: sitter_auth.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch current sitter data
$stmt = $conn->prepare("SELECT * FROM sitters WHERE user_id = ?");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$sitter = $stmt->get_result()->fetch_assoc() ?? [];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = trim($_POST['phone'] ?? '');
    $experience = intval($_POST['experience'] ?? 0);
    $bio = trim($_POST['bio'] ?? '');
    $rate_type = $_POST['rate_type'] ?? 'hourly';
    $rate_amount = floatval($_POST['rate_amount'] ?? 0);
    $availability = $_POST['availability'] ?? 'available';
    $location = trim($_POST['location'] ?? '');

    // Handle profile photo upload
    $profile_photo = $sitter['profile_photo'] ?? '';
    if (isset($_POST['remove_photo']) && $_POST['remove_photo'] == '1') {
        if (!empty($profile_photo) && file_exists($profile_photo)) unlink($profile_photo);
        $profile_photo = '';
    } elseif (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['profile_photo']['tmp_name'];
        $fileExt = strtolower(pathinfo($_FILES['profile_photo']['name'], PATHINFO_EXTENSION));
        $allowedExt = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($fileExt, $allowedExt)) {
            $newFileName = 'uploads/' . uniqid('sitter_', true) . '.' . $fileExt;
            move_uploaded_file($fileTmpPath, $newFileName);
            if (!empty($profile_photo) && file_exists($profile_photo)) unlink($profile_photo);
            $profile_photo = $newFileName;
        }
    }

    // Update or create sitter profile
    if (!empty($sitter)) {
        $update = "UPDATE sitters 
                   SET phone=?, experience=?, bio=?, rate_type=?, rate_amount=?, availability=?, location=?, profile_photo=? 
                   WHERE user_id=?";
        $stmt = $conn->prepare($update);
        $stmt->bind_param('sissdsssi', $phone, $experience, $bio, $rate_type, $rate_amount, $availability, $location, $profile_photo, $user_id);
        $stmt->execute();
        $msg = "Profile updated successfully!";
    } else {
        $insert = "INSERT INTO sitters (user_id, phone, experience, bio, rate_type, rate_amount, availability, location, profile_photo) 
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insert);
        $stmt->bind_param('isissdsss', $user_id, $phone, $experience, $bio, $rate_type, $rate_amount, $availability, $location, $profile_photo);
        $stmt->execute();
        $msg = "Profile created successfully!";
    }

    echo "<script>alert('$msg'); window.location.href='sitters_dashboard.php';</script>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Profile | ChaguaSitter</title>
<style>
body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background-color: #f4f6f9;
}
.wrapper {
    display: flex;
    min-height: 100vh;
}
.sidebar {
    width: 230px;
    background-color: #ff6f00;
    color: #fff;
    padding-top: 30px;
}
.sidebar h2 {
    text-align: center;
    margin-bottom: 30px;
}
.sidebar a {
    color: white;
    text-decoration: none;
    padding: 15px 20px;
    display: block;
}
.sidebar a:hover, .sidebar a.active {
    background-color: #e65c00;
}
.main-content {
    flex: 1;
    padding: 30px 40px;
}
.top-bar {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 20px;
}
.logout-btn {
    background-color: #444;
    color: white;
    padding: 8px 15px;
    border-radius: 6px;
    text-decoration: none;
}
.container {
    background: #fff;
    padding: 25px 30px;
    border-radius: 12px;
    box-shadow: 0 6px 18px rgba(0,0,0,0.1);
}
h2 {
    color: #ff6f00;
    text-align: center;
    margin-bottom: 25px;
}
form label {
    font-weight: 600;
    display: block;
    margin-bottom: 6px;
}
input, textarea, select {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border-radius: 6px;
    border: 1px solid #ccc;
}
.profile-photo {
    display: block;
    margin: 0 auto 15px;
    width: 130px;
    height: 130px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid #ff6f00;
}
.btn {
    background-color: #ff6f00;
    color: white;
    padding: 10px 20px;
    border-radius: 6px;
    text-decoration: none;
    border: none;
    cursor: pointer;
    font-weight: bold;
}
.btn:hover { background-color: #e65c00; }
.btn.secondary { background-color: #555; }
.btn.secondary:hover { background-color: #333; }
.btn-container { text-align: center; }
.remove-photo {
    color: #d9534f;
    cursor: pointer;
    text-align: center;
    display: block;
    font-size: 13px;
}
footer {
    text-align: center;
    padding: 15px;
    background-color: #333;
    color: white;
    margin-top: 40px;
    font-size: 12px;
}
@media (max-width: 768px) {
    .wrapper { flex-direction: column; }
    .sidebar { width: 100%; display: flex; justify-content: space-around; }
}
</style>
</head>
<body>
<div class="wrapper">
    <div class="sidebar">
        <h2>ChaguaSitter</h2>
        <a href="sitters_Dashboard.php">Dashboard</a>
        <a href="edit_profile.php" class="active">Edit Profile</a>
        <a href="view_bookings.php">View Bookings</a>
    </div>

    <div class="main-content">
        <div class="top-bar">
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>

        <div class="container">
            <h2>Edit Your Profile</h2>

            <?php $photoPath = !empty($sitter['profile_photo']) ? $sitter['profile_photo'] : 'images/default_sitter.png'; ?>

            <img id="photoPreview" src="<?php echo htmlspecialchars($photoPath); ?>" alt="Profile Photo" class="profile-photo">

            <form method="POST" enctype="multipart/form-data">
                <label for="profile_photo">Change Profile Photo</label>
                <input type="file" name="profile_photo" id="profile_photo" accept="image/*" onchange="previewPhoto(event)">
                <?php if (!empty($sitter['profile_photo'])): ?>
                    <label class="remove-photo"><input type="checkbox" name="remove_photo" value="1"> Remove current photo</label>
                <?php endif; ?>

                <label for="phone">Phone Number</label>
                <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($sitter['phone'] ?? ''); ?>" required>

                <label for="experience">Experience (Years)</label>
                <input type="number" id="experience" name="experience" min="0" value="<?php echo htmlspecialchars($sitter['experience'] ?? ''); ?>" required>

                <label for="rate_type">Rate Type</label>
                <select id="rate_type" name="rate_type" required>
                    <option value="hourly" <?php if(($sitter['rate_type'] ?? '') == 'hourly') echo 'selected'; ?>>Hourly</option>
                    <option value="daily" <?php if(($sitter['rate_type'] ?? '') == 'daily') echo 'selected'; ?>>Daily</option>
                    <option value="weekly" <?php if(($sitter['rate_type'] ?? '') == 'weekly') echo 'selected'; ?>>Weekly</option>
                </select>

                <label for="rate_amount">Rate Amount (Ksh)</label>
                <input type="number" id="rate_amount" name="rate_amount" step="0.01" min="0" value="<?php echo htmlspecialchars($sitter['rate_amount'] ?? ''); ?>" required>

                <label for="availability">Availability</label>
                <select id="availability" name="availability">
                    <option value="available" <?php if(($sitter['availability'] ?? '') == 'available') echo 'selected'; ?>>Available</option>
                    <option value="unavailable" <?php if(($sitter['availability'] ?? '') == 'unavailable') echo 'selected'; ?>>Unavailable</option>
                </select>

                <label for="location">Location</label>
                <input type="text" id="location" name="location" value="<?php echo htmlspecialchars($sitter['location'] ?? ''); ?>" required>

                <label for="bio">Bio / About You</label>
                <textarea id="bio" name="bio" placeholder="Tell parents about your babysitting experience..."><?php echo htmlspecialchars($sitter['bio'] ?? ''); ?></textarea>

                <div class="btn-container">
                    <button type="submit" class="btn">Save Profile</button>
                    <a href="sitters_Dashboard.php" class="btn secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

<footer>&copy; <?php echo date('Y'); ?> ChaguaSitter. All rights reserved.</footer>

<script>
function previewPhoto(event) {
    const reader = new FileReader();
    reader.onload = function() {
        document.getElementById('photoPreview').src = reader.result;
    }
    reader.readAsDataURL(event.target.files[0]);
}
</script>
<script src="script.js"></script>
</body>
</html>
