<?php
session_start();
include 'db_connect.php';

// Ensure the user is logged in as a parent
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'parent') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle profile picture upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_photo'])) {
    if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] === 0) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/jpg'];
        if (in_array($_FILES['profile_photo']['type'], $allowed_types)) {
            $ext = pathinfo($_FILES['profile_photo']['name'], PATHINFO_EXTENSION);
            $new_filename = 'uploads/profile_' . $user_id . '.' . $ext;
            if (!is_dir('uploads')) mkdir('uploads', 0777, true);

            if (move_uploaded_file($_FILES['profile_photo']['tmp_name'], $new_filename)) {
                // Update database with new profile photo path
                $stmt = $conn->prepare("UPDATE parents SET profile_photo = ? WHERE user_id = ?");
                $stmt->bind_param("si", $new_filename, $user_id);
                $stmt->execute();
                $message = "✅ Profile photo updated successfully!";
            } else {
                $error = "❌ Failed to upload image.";
            }
        } else {
            $error = "❌ Only JPG, JPEG, and PNG files are allowed.";
        }
    } else {
        $error = "❌ Please select a file to upload.";
    }
}

// Fetch parent + user details
$query = "SELECT p.*, u.fullname, u.email, u.role AS user_role, u.created_at 
          FROM parents p 
          JOIN users u ON p.user_id = u.id 
          WHERE p.user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$parent = $result->fetch_assoc();

// Defaults if not found
if (!$parent) {
    $parent = [
        'fullname'   => 'Parent',
        'email'      => 'Not available',
        'phone'      => 'Not available',
        'address'    => 'Not available',
        'user_role'  => $_SESSION['role'] ?? 'parent',
        'created_at' => date('Y-m-d'),
        'profile_photo' => 'assets/user.png',
    ];
}

// Determine profile picture
$profile_photo = $parent['profile_photo'] ?? 'assets/user.png';
if (!file_exists($profile_photo)) $profile_photo = 'assets/user.png';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Profile | ChaguaSitter</title>
<style>
body {
    font-family: "Poppins", sans-serif;
    background: #f2f6f7;
    margin: 0;
    color: #333;
    display: flex;
    flex-direction: column;
    min-height: 100vh;
}

header {
    background-color: #2b6777;
    color: white;
    padding: 15px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
header h2 { margin: 0; }
.nav-right a { color: white; text-decoration: none; margin-left: 20px; font-weight: bold; }
.nav-right a:hover { text-decoration: underline; }

.sidebar {
    background-color: #52ab98;
    width: 230px;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    padding-top: 80px;
    display: flex;
    flex-direction: column;
    transition: 0.3s;
    overflow-y: auto;
}
.sidebar a { color: white; padding: 15px 20px; text-decoration: none; display: block; font-weight: 500; }
.sidebar a:hover { background-color: #3f8b79; }

.menu-toggle { display: none; font-size: 24px; background: none; border: none; color: white; cursor: pointer; }

.main-content { margin-left: 230px; padding: 40px; flex: 1; }
@media (max-width: 768px) {
    .sidebar { left: -230px; }
    .sidebar.active { left: 0; }
    .menu-toggle { display: block; }
    .main-content { margin-left: 0; padding: 20px; }
}

.profile-header {
    display: flex;
    align-items: center;
    gap: 20px;
    border-bottom: 2px solid #52ab98;
    padding-bottom: 15px;
    margin-bottom: 20px;
}
.profile-header img {
    border-radius: 50%;
    width: 120px;
    height: 120px;
    border: 3px solid #52ab98;
    object-fit: cover;
}

h3 { color: #2b6777; border-bottom: 2px solid #52ab98; padding-bottom: 5px; }
.details p { font-size: 16px; margin: 8px 0; color: #555; }

.btn {
    background: #52ab98;
    border: none;
    padding: 10px 20px;
    border-radius: 10px;
    color: white;
    cursor: pointer;
    text-decoration: none;
    font-weight: bold;
    display: inline-block;
    margin-top: 15px;
    transition: 0.3s;
}
.btn:hover { background: #3f8b79; }

footer {
    background-color: #2b6777;
    color: white;
    text-align: center;
    padding: 15px;
    margin-top: auto;
}

.error { color: red; margin-top: 10px; }
.success { color: green; margin-top: 10px; }
</style>
</head>
<body>

<header>
  <div style="display: flex; align-items: center; gap: 15px;">
    <button class="menu-toggle" onclick="toggleMenu()">☰</button>
    <h2>ChaguaSitter | My Profile</h2>
  </div>
  <div class="nav-right">
    <a href="profile.php">Profile</a>
    <a href="logout.php">Logout</a>
  </div>
</header>

<div class="sidebar" id="sidebar">
  <a href="parent_dashboard.php">Dashboard</a>
  <a href="explore_sitters.php">Explore Sitters</a>
  <a href="bookings.php">My Bookings</a>
  <a href="messages.php"> Messages</a>
  <a href="payments.php">Payments</a>
</div>

<div class="main-content">
  <div class="profile-header">
    <img src="<?php echo htmlspecialchars($profile_photo); ?>" alt="Profile Picture">
    <div>
      <h2><?php echo htmlspecialchars($parent['fullname'] ?? 'Parent'); ?></h2>
      <p><strong>Email:</strong> <?php echo htmlspecialchars($parent['email'] ?? 'Not available'); ?></p>
      <p><strong>Role:</strong> <?php echo htmlspecialchars(ucfirst($parent['user_role'] ?? $_SESSION['role'])); ?></p>
    </div>
  </div>

  <!-- Profile Picture Upload -->
  <form method="POST" enctype="multipart/form-data">
    <label for="profile_photo">Change Profile Picture:</label><br>
    <input type="file" name="profile_photo" id="profile_photo" accept="image/*" required>
    <button type="submit" name="upload_photo" class="btn">Upload</button>
  </form>

  <?php if (!empty($error)) echo "<p class='error'>{$error}</p>"; ?>
  <?php if (!empty($message)) echo "<p class='success'>{$message}</p>"; ?>

  <div class="details">
    <h3>Account Details</h3>
    <p><strong>Phone:</strong> <?php echo htmlspecialchars($parent['phone'] ?? 'Not available'); ?></p>
    <p><strong>Address:</strong> <?php echo htmlspecialchars($parent['address'] ?? 'Not available'); ?></p>
    <p><strong>Joined On:</strong> <?php echo date('d M Y', strtotime($parent['created_at'] ?? date('Y-m-d'))); ?></p>
  </div>

  <a href="profile_settings.php" class="btn">Edit Profile</a>
</div>

<footer>
  <p>© <?php echo date("Y"); ?> ChaguaSitter. All Rights Reserved.</p>
</footer>

<script>
function toggleMenu() {
  document.getElementById('sidebar').classList.toggle('active');
}
</script>
<script src="script.js"></script>
</body>
</html>
