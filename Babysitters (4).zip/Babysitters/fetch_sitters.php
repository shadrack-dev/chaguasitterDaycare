<?php
include 'db_connect.php';

$location = $_GET['location'] ?? '';
$availability = $_GET['availability'] ?? '';
$rate_type = $_GET['rate_type'] ?? '';

$where = [];
if($location!=='') $where[] = "u.location LIKE '%".mysqli_real_escape_string($conn,$location)."%'";
if($availability!=='') $where[] = "s.availability='".mysqli_real_escape_string($conn,$availability)."'";
if($rate_type!=='') $where[] = "s.rate_type='".mysqli_real_escape_string($conn,$rate_type)."'";
$whereSQL = $where ? "WHERE ".implode(" AND ",$where) : "";

$sql = "
    SELECT s.sitter_id, u.fullname, u.location, s.experience, s.rate_type, s.rate_amount, s.profile_photo, s.availability
    FROM sitters s
    JOIN users u ON s.user_id = u.id
    $whereSQL
    ORDER BY s.availability DESC
";
$result = mysqli_query($conn,$sql);
$sitters = [];
while($row=mysqli_fetch_assoc($result)){
    $sitters[]=$row;
}
echo json_encode($sitters);
