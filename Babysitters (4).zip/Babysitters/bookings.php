<?php 
session_start();
include 'db_connect.php';

// Ensure parent is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'parent') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch parent info
$stmt = $conn->prepare("SELECT parent_id, num_children FROM parents WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$parent = $stmt->get_result()->fetch_assoc();

if (!$parent) {
    die("Parent account not found.");
}

$parent_id = $parent['parent_id'];

// DAILY LIMITS
$parent_daily_limit = 3;
$system_daily_limit = 20;

$today = date("Y-m-d");

// Parent today count
$stmt = $conn->prepare("SELECT COUNT(*) AS total FROM bookings WHERE parent_id = ? AND DATE(booking_date) = ?");
$stmt->bind_param("is", $parent_id, $today);
$stmt->execute();
$parent_count = $stmt->get_result()->fetch_assoc()['total'];

// System today count
$stmt = $conn->prepare("SELECT COUNT(*) AS total FROM bookings WHERE DATE(booking_date) = ?");
$stmt->bind_param("s", $today);
$stmt->execute();
$system_count = $stmt->get_result()->fetch_assoc()['total'];

$parent_left = max(0, $parent_daily_limit - $parent_count);
$system_left = max(0, $system_daily_limit - $system_count);

$slots_left = min($parent_left, $system_left);

$progress_percentage = round(($system_count / $system_daily_limit) * 100);

$limit_reached = $slots_left <= 0;
$message = $system_left <= 0 
    ? "System booking limit reached. Please try again tomorrow."
    : ($parent_left <= 0 ? "You have reached your booking limit for today." : "");

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Booking | ChaguaSitter</title>
<style>
  body { font-family: 'Poppins', sans-serif; background: #f5f5f5; margin: 0; }
  header { background: #f68b1e; padding: 15px 40px; color: #fff; display: flex; justify-content: space-between; align-items: center; }
  .container { background: #fff; max-width: 700px; margin: 35px auto; padding: 25px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
  .btn { background: #f68b1e; color: #fff; padding: 12px; border: none; border-radius: 6px; width: 100%; cursor: pointer; font-size: 16px; }
  .btn.disabled { background: #ccc; cursor: not-allowed; }
  select, input { width: 100%; padding: 10px; margin-top: 5px; border-radius: 6px; border: 1px solid #ccc; }
  .slots { padding: 12px; background: #e0f7fa; border-left: 5px solid #00acc1; margin-bottom: 20px; text-align: center; font-size: 16px; }
  .notice { padding: 12px; background: #fff3e0; border-left: 5px solid #f68b1e; text-align: center; margin-bottom: 20px; }
  .progress-container { background: #e0e0e0; border-radius: 10px; overflow: hidden; height: 20px; margin-bottom: 20px; }
  .progress-bar { height: 100%; background: #f68b1e; color: #fff; text-align: center; font-size: 12px; line-height: 20px; }
</style>
</head>
<body>

<header>
  <h2>ChaguaSitter | Add Booking</h2>
  <nav><a href="my_bookings.php" style="color:white;">My Bookings</a></nav>
</header>

<div class="container">

<h2 style="text-align:center; color:#f68b1e;">New Booking</h2>

<?php if (!$limit_reached): ?>
  <div class="slots">Available Slots Today: <?= $slots_left ?></div>

  <div class="progress-container">
    <div class="progress-bar" style="width: <?= $progress_percentage ?>%;">
      <?= $progress_percentage ?>%
    </div>
  </div>
<?php endif; ?>

<?php if ($limit_reached): ?>

    <div class="notice"><?= $message ?></div>
    <button class="btn disabled" disabled>Booking Disabled</button>

<?php else: ?>

    <form method="POST" action="process_booking.php">

      <input type="hidden" name="parent_id" value="<?= $parent_id ?>">

      <label>Select Sitter:</label>
      <select name="sitter_id" required>
        <option value="">-- Select Sitter --</option>
        <?php
          $q = $conn->query("SELECT s.sitter_id, u.fullname FROM sitters s JOIN users u ON s.user_id=u.id ORDER BY u.fullname");
          while ($row = $q->fetch_assoc()) {
            echo "<option value='{$row['sitter_id']}'>" . htmlspecialchars($row['fullname']) . "</option>";
          }
        ?>
      </select>

      <label>Booking Date:</label>
      <input type="date" name="booking_date" required min="<?= date('Y-m-d'); ?>">

      <label>Duration (hours):</label>
      <input type="number" name="duration" required min="1" max="12">

      <button type="submit" class="btn">Confirm Booking</button>

    </form>

<?php endif; ?>

</div>

<footer style="background:#f68b1e; color:white; padding:10px; text-align:center; margin-top:40px;">
  © <?= date("Y") ?> ChaguaSitter
</footer>
<script src="script.js"></script>
</body>
</html>
