<?php
session_start();
include('db_connect.php');

// Ensure sitter is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'sitter') {
    header('Location: index.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Get sitter_id from sitters table
$stmtSitterId = $conn->prepare("SELECT sitter_id, profile_photo FROM sitters WHERE user_id = ?");
$stmtSitterId->bind_param("i", $user_id);
$stmtSitterId->execute();
$sitterData = $stmtSitterId->get_result()->fetch_assoc();
$sitter_id = $sitterData['sitter_id'] ?? 0;
$profile_photo = !empty($sitterData['profile_photo']) ? $sitterData['profile_photo'] : 'images/default_sitter.png';

// --- Handle profile photo removal ---
if (isset($_GET['remove_photo'])) {
    if (!empty($profile_photo) && file_exists($profile_photo)) {
        unlink($profile_photo);
    }
    $update = $conn->prepare("UPDATE sitters SET profile_photo = NULL WHERE user_id = ?");
    $update->bind_param("i", $user_id);
    $update->execute();
    echo "<script>alert('Profile photo removed successfully!'); window.location.href='sitters_Dashboard.php';</script>";
    exit();
}

// --- Handle gallery photo removal ---
if (isset($_GET['remove_gallery'])) {
    $photo_id = intval($_GET['remove_gallery']);
    $photoData = $conn->prepare("SELECT photo_path FROM sitters_photos WHERE id = ? AND sitter_id = ?");
    $photoData->bind_param("ii", $photo_id, $sitter_id);
    $photoData->execute();
    $photoResult = $photoData->get_result()->fetch_assoc();
    if ($photoResult && file_exists($photoResult['photo_path'])) unlink($photoResult['photo_path']);

    $delete = $conn->prepare("DELETE FROM sitters_photos WHERE id = ? AND sitter_id = ?");
    $delete->bind_param("ii", $photo_id, $sitter_id);
    $delete->execute();
    echo json_encode(['status'=>'success']);
    exit();
}

// --- Handle gallery upload ---
if (isset($_FILES['gallery_photos'])) {
    $uploadDir = 'uploads/';
    $uploadedFiles = [];

    foreach ($_FILES['gallery_photos']['tmp_name'] as $key => $tmp_name) {
        if ($_FILES['gallery_photos']['error'][$key] === UPLOAD_ERR_OK) {
            $fileExt = strtolower(pathinfo($_FILES['gallery_photos']['name'][$key], PATHINFO_EXTENSION));
            if (in_array($fileExt, ['jpg','jpeg','png','gif'])) {
                $newFileName = $uploadDir . uniqid() . '.' . $fileExt;
                if (move_uploaded_file($tmp_name, $newFileName)) {
                    $insert = $conn->prepare("INSERT INTO sitters_photos (sitter_id, photo_path) VALUES (?, ?)");
                    $insert->bind_param("is", $sitter_id, $newFileName);
                    $insert->execute();
                    $photo_id = $conn->insert_id;
                    $uploadedFiles[] = ['id'=>$photo_id, 'path'=>$newFileName];
                }
            }
        }
    }
    echo json_encode(['status'=>'success', 'files'=>$uploadedFiles]);
    exit();
}

// --- Fetch sitter info ---
$stmt = $conn->prepare("
    SELECT s.*, u.fullname, u.email
    FROM sitters s
    JOIN users u ON s.user_id = u.id
    WHERE s.user_id = ?
");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$sitter = $stmt->get_result()->fetch_assoc();

// --- Fetch gallery photos ---
$galleryStmt = $conn->prepare("SELECT id, photo_path FROM sitters_photos WHERE sitter_id = ?");
$galleryStmt->bind_param("i", $sitter_id);
$galleryStmt->execute();
$gallery = $galleryStmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Booking summary
$totalBookings = $conn->query("SELECT COUNT(*) AS total FROM bookings WHERE sitter_id = $sitter_id")->fetch_assoc()['total'] ?? 0;
$pending = $conn->query("SELECT COUNT(*) AS total FROM bookings WHERE sitter_id = $sitter_id AND status='pending'")->fetch_assoc()['total'] ?? 0;
$completed = $conn->query("SELECT COUNT(*) AS total FROM bookings WHERE sitter_id = $sitter_id AND status='completed'")->fetch_assoc()['total'] ?? 0;
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sitter Dashboard | ChaguaSitter</title>
<style>
/* Same styles as your previous file */
body { font-family: 'Poppins', sans-serif; background: #f4f6f8; margin:0; }
.wrapper { display:flex; min-height:100vh; }
.sidebar { width:230px; background:#ff6f00; color:white; padding-top:30px; flex-shrink:0; }
.sidebar h2 { text-align:center; margin-bottom:30px; font-size:22px; }
.sidebar a { color:white; text-decoration:none; padding:14px 20px; display:block; transition:0.3s; }
.sidebar a:hover, .sidebar a.active { background:#e65c00; }
.main-content { flex:1; padding:30px; }
.top-bar { display:flex; justify-content:flex-end; margin-bottom:20px; }
.logout-btn { background:#333; color:white; padding:8px 16px; border-radius:6px; text-decoration:none; font-weight:bold; }
.logout-btn:hover { background:#111; }
.stats { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:20px; margin-bottom:30px; }
.card { background:white; padding:20px; border-radius:12px; text-align:center; box-shadow:0 2px 10px rgba(0,0,0,0.1); }
.card h3 { color:#ff6f00; font-size:18px; margin-bottom:10px; }
.card p { font-size:22px; font-weight:bold; color:#333; }
.profile { background:white; padding:25px; border-radius:12px; box-shadow:0 2px 10px rgba(0,0,0,0.1); display:flex; gap:20px; flex-wrap:wrap; }
.profile img { width:130px; height:130px; border-radius:50%; object-fit:cover; border:4px solid #ff6f00; }
.photo-actions { text-align:center; margin-top:8px; }
.remove-photo, .remove-gallery { background:#c0392b; color:white; border:none; padding:6px 12px; border-radius:5px; font-size:13px; cursor:pointer; }
.remove-photo:hover, .remove-gallery:hover { background:#a93226; }
.profile-info { flex:1; }
.profile-info h2 { margin:0; color:#ff6f00; font-size:22px; }
.profile-info p { margin:6px 0; color:#333; font-size:15px; }
.btn-container { margin-top:15px; }
.btn { background:#ff6f00; color:white; padding:10px 18px; border-radius:6px; text-decoration:none; font-weight:bold; margin-right:10px; transition:0.3s; }
.btn:hover { background:#e65c00; }
.btn.green { background:#27ae60; }
.btn.green:hover { background:#219150; }
.gallery { margin-top:20px; display:flex; flex-wrap:wrap; gap:10px; }
.gallery-item { position:relative; }
.gallery img { width:120px; height:120px; object-fit:cover; border-radius:8px; border:2px solid #ff6f00; }
.remove-gallery { position:absolute; top:4px; right:4px; font-size:12px; padding:4px 6px; }
.upload-area { border:2px dashed #ff6f00; padding:20px; border-radius:10px; text-align:center; color:#ff6f00; cursor:pointer; margin-top:20px; transition:0.3s; }
.upload-area.dragover { background:#ffe0b2; color:#e65c00; }
footer { text-align:center; padding:15px; background:#333; color:white; margin-top:40px; font-size:12px; }
@media(max-width:768px) { .wrapper{flex-direction:column;} .sidebar{width:100%; display:flex; overflow-x:auto;} .sidebar a{flex:1;text-align:center;} .profile{flex-direction:column;align-items:center;text-align:center;} }
</style>
</head>
<body>
<div class="wrapper">
    <div class="sidebar">
        <h2>ChaguaSitter</h2>
        <a href="sitters_Dashboard.php" class="active">Dashboard</a>
        <a href="edit_profile.php">Edit Profile</a>
        <a href="view_bookings.php">View Bookings</a>
    </div>
    <div class="main-content">
        <div class="top-bar">
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
        <div class="stats">
            <div class="card"><h3>Total Bookings</h3><p><?php echo $totalBookings; ?></p></div>
            <div class="card"><h3>Pending</h3><p><?php echo $pending; ?></p></div>
            <div class="card"><h3>Completed</h3><p><?php echo $completed; ?></p></div>
        </div>

        <div class="profile">
            <div>
                <img src="<?php echo htmlspecialchars($profile_photo); ?>" alt="Profile Photo">
                <?php if ($profile_photo !== 'images/default_sitter.png') { ?>
                <div class="photo-actions">
                    <form method="get" onsubmit="return confirm('Are you sure you want to remove your photo?');">
                        <button type="submit" name="remove_photo" class="remove-photo">Remove Photo</button>
                    </form>
                </div>
                <?php } ?>
            </div>
            <div class="profile-info">
                <h2><?php echo htmlspecialchars($sitter['fullname']); ?></h2>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($sitter['email']); ?></p>
                <p><strong>Phone:</strong> <?php echo htmlspecialchars($sitter['phone'] ?? 'Not set'); ?></p>
                <p><strong>Location:</strong> <?php echo htmlspecialchars($sitter['location'] ?? 'Not set'); ?></p>
                <p><strong>Experience:</strong> <?php echo htmlspecialchars($sitter['experience'] ?? '0'); ?> years</p>
                <p><strong>Rate:</strong> <?php echo !empty($sitter['rate_amount']) ? "Ksh " . number_format($sitter['rate_amount'],2) . " / " . ucfirst($sitter['rate_type']) : "Not set"; ?></p>
                <p><strong>Availability:</strong> <?php echo htmlspecialchars($sitter['availability'] ?? 'available'); ?></p>
                <p><strong>Bio:</strong><br><?php echo nl2br(htmlspecialchars($sitter['bio'] ?? 'No bio added yet.')); ?></p>
                <div class="btn-container">
                    <a href="edit_profile.php" class="btn">Edit Profile</a>
                    <a href="edit_rate.php" class="btn green">Edit Rate</a>
                </div>
            </div>
        </div>

        <div class="gallery" id="gallery">
            <?php foreach($gallery as $img) { ?>
            <div class="gallery-item" data-id="<?php echo $img['id']; ?>">
                <img src="<?php echo htmlspecialchars($img['photo_path']); ?>" alt="Gallery Photo">
                <button class="remove-gallery">x</button>
            </div>
            <?php } ?>
        </div>

        <div id="upload-area" class="upload-area">
            Drag & Drop Gallery Photos Here or Click to Upload
            <input type="file" id="galleryInput" multiple style="display:none;">
        </div>
    </div>
</div>
<footer>&copy; <?php echo date('Y'); ?> ChaguaSitter. All rights reserved.</footer>

<script>
const uploadArea = document.getElementById('upload-area');
const galleryInput = document.getElementById('galleryInput');
const galleryDiv = document.getElementById('gallery');

uploadArea.addEventListener('click', () => galleryInput.click());
uploadArea.addEventListener('dragover', e => { e.preventDefault(); uploadArea.classList.add('dragover'); });
uploadArea.addEventListener('dragleave', () => uploadArea.classList.remove('dragover'));
uploadArea.addEventListener('drop', e => { e.preventDefault(); uploadArea.classList.remove('dragover'); handleFiles(e.dataTransfer.files); });
galleryInput.addEventListener('change', () => handleFiles(galleryInput.files));

function handleFiles(files) {
    const formData = new FormData();
    for (let i = 0; i < files.length; i++) formData.append('gallery_photos[]', files[i]);

    fetch('sitters_Dashboard.php', { method: 'POST', body: formData })
    .then(res => res.json())
    .then(data => {
        if(data.status==='success') {
            data.files.forEach(file => {
                const div = document.createElement('div');
                div.className = 'gallery-item';
                div.innerHTML = `<img src="${file.path}" alt="Gallery Photo"><button class="remove-gallery">x</button>`;
                galleryDiv.appendChild(div);
                addRemoveHandler(div);
            });
        } else { alert('Upload failed.'); }
    })
    .catch(() => alert('Upload failed.'));
}

function addRemoveHandler(div) {
    const btn = div.querySelector('.remove-gallery');
    btn.addEventListener('click', () => {
        if(confirm('Remove this photo?')) {
            const id = div.getAttribute('data-id');
            fetch(`sitters_Dashboard.php?remove_gallery=${id}`)
            .then(res => res.json())
            .then(data => { if(data.status==='success') div.remove(); });
        }
    });
}

document.querySelectorAll('.gallery-item').forEach(div => addRemoveHandler(div));
</script>
<script src="script.js"></script>
</body>
</html>
