<?php
session_start();
include('db_connect.php');

// Only allow admin
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: login.php");
    exit();
}

// Check if parent ID is provided
if(!isset($_GET['id'])){
    die("Invalid parent ID.");
}

$parent_id = intval($_GET['id']);

// Fetch parent data
$query = mysqli_query($conn, "SELECT * FROM users WHERE id='$parent_id' AND role='parent'");
$parent = mysqli_fetch_assoc($query);

// If no record found
if(!$parent){
    die("Parent not found.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>View Parent | ChaguaSitter Admin</title>
<style>
    body { font-family: Poppins, sans-serif; background: #f6f6f6; margin: 0; }
    .container { width: 90%; max-width: 700px; margin: 40px auto; background: #fff; padding: 25px;
                 border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
    h2 { text-align: center; color: #ff9900; margin-bottom: 25px; }
    .detail { margin: 15px 0; font-size: 16px; }
    .label { font-weight: 600; color: #333; }
    .value { color: #555; margin-left: 10px; }
    a.back-btn { display: inline-block; margin-top: 25px; padding: 10px 15px; background: #ff9900;
                 color: white; text-decoration: none; border-radius: 6px; }
    a.back-btn:hover { background: #e68a00; }
</style>
</head>
<body>

<div class="container">
    <h2>Parent Details</h2>

    <div class="detail"><span class="label">Full Name:</span><span class="value">
        <?php echo htmlspecialchars($parent['fullname']); ?></span></div>

    <div class="detail"><span class="label">Email:</span><span class="value">
        <?php echo htmlspecialchars($parent['email']); ?></span></div>

    <div class="detail"><span class="label">Phone:</span><span class="value">
        <?php echo isset($parent['phone']) ? htmlspecialchars($parent['phone']) : 'Not Provided'; ?></span></div>

    <div class="detail"><span class="label">Location:</span><span class="value">
        <?php echo isset($parent['location']) ? htmlspecialchars($parent['location']) : 'No Location'; ?></span></div>

    <div class="detail"><span class="label">Date Joined:</span><span class="value">
        <?php echo date('d M Y', strtotime($parent['created_at'])); ?></span></div>

    <a href="manage_parents.php" class="back-btn">← Back to Parents</a>
</div>
<script src="script.js"></script>
</body>
</html>
