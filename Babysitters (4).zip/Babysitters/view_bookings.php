<?php
session_start();
include 'db_connect.php';

// Ensure only logged-in parents can view their bookings
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'parent') {
  header('Location: index.php');
  exit();
}

$user_id = $_SESSION['user_id'];

// Get the parent's ID
$parentQuery = "SELECT parent_id, num_children FROM parents WHERE user_id = ?";
$stmt = $conn->prepare($parentQuery);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$parentResult = $stmt->get_result();
$parentData = $parentResult->fetch_assoc();

if (!$parentData) {
  die("Parent record not found.");
}

$parent_id = $parentData['parent_id'];
$num_children = (int)$parentData['num_children']; // assume this field exists

// Set per-parent daily booking limit
$daily_limit = 3;

// Count today’s bookings for this parent
$today = date('Y-m-d');
$checkQuery = "SELECT COUNT(*) AS count FROM bookings WHERE parent_id = ? AND DATE(booking_date) = ?";
$stmt = $conn->prepare($checkQuery);
$stmt->bind_param('is', $parent_id, $today);
$stmt->execute();
$resultCheck = $stmt->get_result();
$todayCount = $resultCheck->fetch_assoc()['count'];

// Fetch parent’s bookings
$query = "
  SELECT 
    b.booking_id,
    b.booking_date,
    b.status,
    s.hourly_rate,
    us.fullname AS sitter_name
  FROM bookings b
  LEFT JOIN sitters s ON b.sitter_id = s.sitter_id
  LEFT JOIN users us ON s.user_id = us.id
  WHERE b.parent_id = ?
  ORDER BY b.booking_date DESC
";
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $parent_id);
$stmt->execute();
$result = $stmt->get_result();

// Function to calculate total cost
function calculatePayment($rate, $num_children) {
  if ($num_children == 1) return $rate;
  elseif ($num_children == 2) return $rate * 1.5;
  else return $rate * 2;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Bookings | ChaguaSitter</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      font-family: "Poppins", sans-serif;
      background: #f8f8f8;
      margin: 0;
    }

    header {
      background-color: #f68b1e;
      color: #fff;
      padding: 15px 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    header h2 {
      margin: 0;
      font-size: 20px;
    }

    .container {
      width: 90%;
      max-width: 1000px;
      margin: 40px auto;
      background: #fff;
      padding: 25px;
      border-radius: 12px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }

    h2 {
      color: #f68b1e;
      text-align: center;
      font-size: 22px;
      margin-bottom: 20px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      font-size: 14px;
    }

    th, td {
      padding: 10px 12px;
      border: 1px solid #ddd;
    }

    th {
      background-color: #f68b1e;
      color: white;
    }

    tr:nth-child(even) {
      background-color: #f9f9f9;
    }

    .btn {
      background-color: #f68b1e;
      color: white;
      padding: 8px 15px;
      text-decoration: none;
      border-radius: 6px;
      font-size: 14px;
    }

    .btn:hover {
      background-color: #e67e1e;
    }

    .disabled-btn {
      background-color: #ccc;
      color: #666;
      cursor: not-allowed;
    }

    .limit-notice {
      background: #fff3e0;
      border-left: 5px solid #f68b1e;
      padding: 10px 15px;
      border-radius: 6px;
      margin-bottom: 15px;
      color: #444;
      font-size: 14px;
    }

    footer {
      background-color: #f68b1e;
      color: #fff;
      text-align: center;
      padding: 12px;
      margin-top: 40px;
      font-size: 13px;
    }
  </style>
</head>
<body>

<header>
  <h2>🧡 ChaguaSitter | My Bookings</h2>
  <nav>
    <a href="parent_Dashboard.php" style="color:white; text-decoration:none;">Dashboard</a>
  </nav>
</header>

<div class="container">
  <h2>Your Bookings</h2>

  <?php if ($todayCount >= $daily_limit): ?>
    <div class="limit-notice">
       You’ve reached your booking limit (<?= $daily_limit ?>) for today. Try again tomorrow.
    </div>
  <?php endif; ?>

  <div style="text-align:right; margin-bottom:15px;">
    <?php if ($todayCount < $daily_limit): ?>
      <a href="add_booking.php" class="btn">+ Add New Booking</a>
    <?php else: ?>
      <a href="#" class="btn disabled-btn">+ Add New Booking</a>
    <?php endif; ?>
  </div>

  <table>
    <tr>
      <th>Booking ID</th>
      <th>Sitter</th>
      <th>Booking Date</th>
      <th>Status</th>
      <th>Total Payment (Ksh)</th>
    </tr>

    <?php
    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        $payment = calculatePayment($row['hourly_rate'], $num_children);
        $color = match($row['status']) {
          'completed' => 'green',
          'cancelled' => 'red',
          default => '#f68b1e'
        };
        echo "
        <tr>
          <td>{$row['booking_id']}</td>
          <td>{$row['sitter_name']}</td>
          <td>{$row['booking_date']}</td>
          <td style='color:$color; font-weight:600;'>{$row['status']}</td>
          <td><strong>Ksh " . number_format($payment, 2) . "</strong></td>
        </tr>";
      }
    } else {
      echo "<tr><td colspan='5' style='text-align:center; color:#888;'>No bookings found</td></tr>";
    }
    ?>
  </table>
</div>

<footer>
  <p>© <?= date("Y") ?> ChaguaSitter. All rights reserved.</p>
</footer>
<script src="script.js"></script>
</body>
</html>
