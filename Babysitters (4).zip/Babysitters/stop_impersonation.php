<?php
session_start();

// Restore admin session
if (!empty($_SESSION['admin_impersonating'])) {
    session_unset();
    session_destroy();

    session_start();
    $_SESSION['role'] = 'admin';
}

header("Location: Admin_Dashboard.php");
exit;
