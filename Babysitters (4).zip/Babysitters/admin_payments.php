<?php
session_start();
include "db_connect.php";
include "config.php";

// Allow only admin
if(!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true){
    header("Location: index.php");
    exit;
}

// Handle status update via POST (manual)
if(isset($_POST['update_status'])){
    $payment_id = $_POST['payment_id'];
    $new_status = $_POST['status'];
    $stmt = $conn->prepare("UPDATE payments SET status=? WHERE payment_id=?");
    $stmt->bind_param("si", $new_status, $payment_id);
    $stmt->execute();
    echo json_encode(["success"=>true]);
    exit;
}

// Handle search/filter
$filter = "";
if(isset($_GET['status']) && $_GET['status'] != ""){
    $status_filter = $_GET['status'];
    $filter = "WHERE status='$status_filter'";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Payments</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
<style>
body{font-family: Arial; margin:20px;}
table{width:100%; border-collapse: collapse;}
th, td{padding:10px; border:1px solid #ddd; text-align:left;}
th{background:#f4f4f4;}
.status-Pending{color: orange; font-weight:bold;}
.status-Completed{color: green; font-weight:bold;}
.status-Failed{color: red; font-weight:bold;}
button{padding:5px 10px; margin:2px; cursor:pointer;}
</style>
</head>
<body>

<h2>Payments Dashboard</h2>

<!-- Filter -->
<form method="GET">
    <label>Filter by status:</label>
    <select name="status" onchange="this.form.submit()">
        <option value="">All</option>
        <option value="Pending" <?php if(isset($status_filter) && $status_filter=="Pending") echo "selected"; ?>>Pending</option>
        <option value="Completed" <?php if(isset($status_filter) && $status_filter=="Completed") echo "selected"; ?>>Completed</option>
        <option value="Failed" <?php if(isset($status_filter) && $status_filter=="Failed") echo "selected"; ?>>Failed</option>
    </select>
</form>
<!-- Export Buttons -->
<button onclick="exportData('pdf')">Download PDF</button>
<button onclick="exportData('excel')">Download Excel</button>

<table id="paymentsTable">
<tr>
    <th>ID</th>
    <th>Booking</th>
    <th>Parent</th>
    <th>Sitter</th>
    <th>Amount</th>
    <th>Method</th>
    <th>Status</th>
    <th>Transaction Code</th>
    <th>Date</th>
    <th>Actions</th>
</tr>
<tbody id="paymentsBody">
<!-- Rows will be loaded via AJAX -->
</tbody>
</table>

<script>
// Load payments via AJAX
function loadPayments(){
    fetch("admin_payments_data.php?status=<?php echo isset($status_filter)?$status_filter:""; ?>")
    .then(res=>res.json())
    .then(data=>{
        let tbody = document.getElementById("paymentsBody");
        tbody.innerHTML = "";
        data.forEach(row=>{
            let tr = document.createElement("tr");
            tr.innerHTML = `
                <td>${row.payment_id}</td>
                <td>${row.booking_id}</td>
                <td>${row.parent_id}</td>
                <td>${row.sitter_id}</td>
                <td>${parseFloat(row.amount).toFixed(2)}</td>
                <td>${row.payment_method}</td>
                <td class="status-${row.status}">${row.status}</td>
                <td>${row.transaction_code}</td>
                <td>${row.created_at}</td>
                <td>
                    <button onclick="updateStatus(${row.payment_id})">Update Status</button>
                    ${row.status=='Pending' && row.payment_method=='Mpesa' ?
                        `<button onclick="triggerMpesa(${row.payment_id},${row.amount},prompt('Enter customer phone:'),${row.booking_id},${row.parent_id},${row.sitter_id})">STK Push</button>` : ""}
                </td>
            `;
            tbody.appendChild(tr);
        });
    });
}

// Update payment status (manual)
function updateStatus(paymentId){
    let newStatus = prompt("Enter new status (Completed / Failed):");
    if(newStatus==="Completed" || newStatus==="Failed"){
        fetch("admin_payments.php", {
            method:"POST",
            headers: {'Content-Type':'application/x-www-form-urlencoded'},
            body: `update_status=1&payment_id=${paymentId}&status=${newStatus}`
        }).then(res=>{
            loadPayments();
        });
    } else alert("Invalid status");
}

// Trigger STK push
function triggerMpesa(paymentId, amount, phone, bookingId, parentId, sitterId){
    fetch("mpesa_stk_push.php", {
        method:"POST",
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({payment_id: paymentId, amount, phone, booking_id: bookingId, parent_id: parentId, sitter_id: sitterId})
    }).then(res=>res.json())
    .then(data=>{
        alert("STK Push Result: "+data.message);
        loadPayments();
    });
}

// Auto-refresh every 10 seconds
setInterval(loadPayments, 10000);
window.onload = loadPayments;
</script>
<script src="script.js"></script>
</body>
</html>
