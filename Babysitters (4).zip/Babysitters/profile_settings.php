<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'] ?? null;
    $experience = $_POST['experience'] ?? null;
    $hourly_rate = $_POST['hourly_rate'] ?? null;
    $availability = $_POST['availability'] ?? null;

    $conn->query("UPDATE users SET fullname='$fullname', email='$email' WHERE id='$user_id'");

    if ($role == 'parent') {
        $conn->query("UPDATE parents SET phone='$phone', address='$address' WHERE user_id='$user_id'");
    } elseif ($role == 'sitter') {
        $conn->query("UPDATE sitters 
                      SET phone='$phone', experience='$experience', hourly_rate='$hourly_rate', availability='$availability' 
                      WHERE user_id='$user_id'");
    }

    header("Location: profile.php");
    exit();
}

$user = $conn->query("SELECT * FROM users WHERE id='$user_id'")->fetch_assoc();
$extra = [];

if ($role == 'parent') {
    $extra = $conn->query("SELECT * FROM parents WHERE user_id='$user_id'")->fetch_assoc();
} elseif ($role == 'sitter') {
    $extra = $conn->query("SELECT * FROM sitters WHERE user_id='$user_id'")->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Profile | ChaguaSitter</title>
<style>
body {
    font-family: "Poppins", sans-serif;
    background: #f5f5f5;
    margin: 0;
    padding: 0;
}
.container {
    background: #fff;
    width: 90%;
    max-width: 600px;
    margin: 50px auto;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 0 8px rgba(0,0,0,0.1);
}
h2 {
    color: #F68B1E;
    text-align: center;
}
label {
    display: block;
    margin-top: 15px;
    font-weight: bold;
    color: #555;
}
input, select {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
}
button {
    background: #F68B1E;
    color: #fff;
    border: none;
    margin-top: 20px;
    padding: 10px;
    width: 100%;
    border-radius: 6px;
    cursor: pointer;
    font-weight: bold;
}
button:hover {
    background: #e67b00;
}
</style>
</head>
<body>

<div class="container">
    <h2>Edit Profile</h2>
    <form method="POST">
        <label>Full Name</label>
        <input type="text" name="fullname" value="<?= $user['fullname'] ?>" required>

        <label>Email</label>
        <input type="email" name="email" value="<?= $user['email'] ?>" required>

        <label>Phone</label>
        <input type="text" name="phone" value="<?= $extra['phone'] ?? '' ?>">

        <?php if ($role == 'parent'): ?>
            <label>Address</label>
            <input type="text" name="address" value="<?= $extra['address'] ?? '' ?>">
        <?php elseif ($role == 'sitter'): ?>
            <label>Experience (Years)</label>
            <input type="number" name="experience" value="<?= $extra['experience'] ?? '' ?>">

            <label>Hourly Rate (Ksh)</label>
            <input type="number" step="0.01" name="hourly_rate" value="<?= $extra['hourly_rate'] ?? '' ?>">

            <label>Availability</label>
            <select name="availability">
                <option value="available" <?= ($extra['availability'] ?? '') == 'available' ? 'selected' : '' ?>>Available</option>
                <option value="unavailable" <?= ($extra['availability'] ?? '') == 'unavailable' ? 'selected' : '' ?>>Unavailable</option>
            </select>
        <?php endif; ?>

        <button type="submit">Save Changes</button>
    </form>
</div>
<script src="script.js"></script>
</body>
</html>|