<?php 
session_start();
include 'db_connect.php';
include 'config.php';

// Default admin/master credentials
if (!isset($ADMIN_MASTER_PASSWORD)) $ADMIN_MASTER_PASSWORD = 'Admin@1234';
if (!isset($REMEMBER_SECRET)) $REMEMBER_SECRET = 'replace_with_a_long_random_secret_in_config';

// Rate-limit settings
$MAX_ATTEMPTS = 3;
$LOCKOUT_SECONDS = 30;

// Helpers
function safe_echo($str) {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

function set_remember_cookie($user_id, $secret) {
    $expiry = time() + 30*24*60*60;
    $payload = $user_id . ':' . $expiry;
    $signature = hash_hmac('sha256', $payload, $secret);
    $token = base64_encode($payload . ':' . $signature);
    setcookie('rememberme', $token, $expiry, '/', '', isset($_SERVER['HTTPS']), true);
}

function clear_remember_cookie() {
    setcookie('rememberme', '', time()-3600, '/', '', isset($_SERVER['HTTPS']), true);
}

// Initialize attempts
if (!isset($_SESSION['login_attempts'])) $_SESSION['login_attempts'] = 0;
if (!isset($_SESSION['last_attempt_time'])) $_SESSION['last_attempt_time'] = 0;

$error = "";

// Dashboard mapping
$dashboard_pages = [
    'admin' => 'Admin_Dashboard.php',
    'sitter' => 'sitters_Dashboard.php',
    'parent' => 'parent_Dashboard.php'
];

// Handle login POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $now = time();

    if ($_SESSION['login_attempts'] >= $MAX_ATTEMPTS && ($now - $_SESSION['last_attempt_time']) < $LOCKOUT_SECONDS) {
        $remaining = $LOCKOUT_SECONDS - ($now - $_SESSION['last_attempt_time']);
        $error = "Too many attempts. Try again in $remaining seconds.";
    } else {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $remember = isset($_POST['remember']);

        if ($email === '' || $password === '') {
            $error = "Please provide both email and password.";
        } else {
            $stmt = $conn->prepare("SELECT id, password, role FROM users WHERE email=? LIMIT 1");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $res = $stmt->get_result();

            if ($res && $res->num_rows === 1) {
                $user = $res->fetch_assoc();
                $valid = false;

                if (!empty($user['password']) && password_verify($password, $user['password'])) $valid = true;
                if (!$valid && $user['role'] === 'admin' && hash_equals($ADMIN_MASTER_PASSWORD, $password)) $valid = true;

                if ($valid) {
                    $_SESSION['login_attempts'] = 0;
                    $_SESSION['last_attempt_time'] = 0;
                    $_SESSION['user_id'] = (int)$user['id'];
                    $_SESSION['role'] = $user['role'];

                    if ($remember) set_remember_cookie($_SESSION['user_id'], $REMEMBER_SECRET);
                    else clear_remember_cookie();

                    session_regenerate_id(true);

                    $redirect = $dashboard_pages[$user['role']] ?? 'login.php';
                    header("Location: $redirect");
                    exit();
                } else {
                    $_SESSION['login_attempts']++;
                    $_SESSION['last_attempt_time'] = time();
                    $remaining = $MAX_ATTEMPTS - $_SESSION['login_attempts'];
                    $error = $_SESSION['login_attempts'] >= $MAX_ATTEMPTS ?
                        "Wrong credentials. Locked for $LOCKOUT_SECONDS sec." :
                        "Invalid Email/Password! $remaining attempt(s) left.";
                }
            } else {
                $_SESSION['login_attempts']++;
                $_SESSION['last_attempt_time'] = time();
                $remaining = $MAX_ATTEMPTS - $_SESSION['login_attempts'];
                $error = $_SESSION['login_attempts'] >= $MAX_ATTEMPTS ?
                    "Invalid Email/Password! Locked for $LOCKOUT_SECONDS sec." :
                    "Invalid Email/Password! $remaining attempt(s) left.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login | ChaguaSitter</title>
<style>
/* =========================
   Global Body
========================= */
body {
    font-family: 'Poppins', sans-serif;
    background: #c09f0bff;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    margin: 0;
    padding: 20px;
}

/* =========================
   Login/Register Box
========================= */
.login-box {
    background: #fff;
    padding: 40px 30px;
    border-radius: 16px;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
    width: 100%;
    max-width: 400px;
    text-align: center;
    display: flex;
    flex-direction: column;
    gap: 20px;
}

/* =========================
   Heading
========================= */
.login-box h2 {
    color: #ff6f00;
    margin-bottom: 20px;
    font-size: 26px;
    font-weight: 600;
}

/* =========================
   Input Fields
========================= */
.input {
    width: 100%;
    padding: 14px;
    margin: 0;
    border: 1px solid #ccc;
    border-radius: 12px;
    font-size: 16px;
}

/* =========================
   Buttons
========================= */
.btn {
    width: 100%;
    padding: 14px;
    background: #ff6f00;
    color: #fff;
    border: none;
    border-radius: 12px;
    font-weight: 600;
    font-size: 16px;
    cursor: pointer;
    transition: background 0.3s ease;
}

.btn:hover {
    background: #e65c00;
}

/* =========================
   Password Wrapper
========================= */
.password-wrapper {
    position: relative;
}

.toggle-password {
    position: absolute;
    right: 15px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    user-select: none;
}

/* =========================
   Messages
========================= */
.msg {
    font-size: 14px;
    margin-top: 10px;
}

.error {
    color: #c62828;
}

/* =========================
   Register Button
========================= */
.register-btn {
    background: #27ae60;
    margin-top: 10px;
}

.register-btn:hover {
    background: #219150;
}
   Checkbox & Links
label {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 14px;
}

a {
    color: #ff6f00;
    text-decoration: none;
    font-weight: 500;
}

a:hover {
    text-decoration: underline;
}

/* =========================
   Responsive
========================= */
@media (max-width: 480px) {
    .login-box {
        padding: 30px 20px;
    }

    .input, .btn {
        padding: 12px;
        font-size: 15px;
    }
}

</style>
</head>
<body>
<div class="login-box">
    <h2>Login</h2>
    <form method="POST">
        <input type="email" class="input" name="email" placeholder="Email" required value="<?php echo safe_echo($_POST['email'] ?? ''); ?>">
        <div class="password-wrapper">
            <input type="password" class="input" name="password" id="password" placeholder="Password" required>
            <span class="toggle-password" id="togglePass">👁️</span>
        </div>
        <label><input type="checkbox" name="remember" value="1"> Remember me</label>
        <button class="btn" type="submit" name="login">Login</button>
    </form>

    <p><a href="forgot_password.php">Forgot Password?</a></p>
    <a href="register.php" class="btn register-btn">Don't have an account? Register</a>

    <?php if($error) echo "<p class='msg error'>".safe_echo($error)."</p>"; ?>
</div>

<script>
const toggle = document.getElementById('togglePass');
const passwordInput = document.getElementById('password');
toggle.addEventListener('click', () => {
    if(passwordInput.type === 'password'){ passwordInput.type='text'; toggle.textContent='🙈'; }
    else { passwordInput.type='password'; toggle.textContent='👁️'; }
});
</script>
<script src="script.js"></script>
</body>
</html>
