<?php
session_start();
include('db_connect.php');

// Allow only admin access
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'admin') {
    header('Location: index.php');
    exit;
}

/* ======================
   FETCH DATA WITH JOINS
   ====================== */

// Parents
$parents = mysqli_query($conn, "
    SELECT 
        p.parent_id AS parent_id,
        u.fullname,
        u.email,
        u.location
    FROM parents p
    INNER JOIN users u ON p.user_id = u.id
");

// Sitters
$sitters = mysqli_query($conn, "
    SELECT 
        s.sitter_id AS sitter_id,
        u.fullname,
        u.email,
        s.experience
    FROM sitters s
    INNER JOIN users u ON s.user_id = u.id
");

// Bookings
$bookings = mysqli_query($conn, "SELECT * FROM bookings");

// Summary counts
$total_parents   = mysqli_num_rows($parents);
$total_sitters   = mysqli_num_rows($sitters);
$total_bookings  = mysqli_num_rows($bookings);

// Booking status counts
$pending   = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM bookings WHERE status='pending'"));
$approved  = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM bookings WHERE status='approved'"));
$completed = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM bookings WHERE status='completed'"));
$cancelled = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM bookings WHERE status='cancelled'"));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard | ChaguaSitter</title>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
/* -------- COLORS -------- */
:root {
    --primary: #1cc88a;
    --accent: #f39c12;
    --bg: #eef2f7;
    --text: #2d3436;
    --card: #ffffff;
    --border: #dcdde1;
}

body.dark {
    --bg: #121212;
    --card: #181818;
    --text: #f1f1f1;
    --border: #333;
}

/* -------- GLOBAL -------- */
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:var(--bg);
    color:var(--text);
    display:flex;
    transition:0.3s;
}

/* ---------- SIDEBAR ---------- */
.sidebar{
    width:260px;
    position:fixed;
    left:0;
    top:0;
    background:var(--card);
    height:100vh;
    padding-top:20px;
    border-right:3px solid var(--primary);
    transition:0.3s;
}

.sidebar h2{
    text-align:center;
    color:var(--primary);
    margin-bottom:20px;
}

.sidebar a{
    display:block;
    padding:15px 30px;
    color:var(--text);
    text-decoration:none;
    border-bottom:1px solid var(--border);
}

.sidebar a:hover{
    background:var(--primary);
    color:white;
}

/* ---------- TOP NAV ---------- */
.topnav{
    width:100%;
    position:fixed;
    left:260px;
    top:0;
    height:60px;
    background:var(--card);
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:0 20px;
    border-bottom:3px solid var(--primary);
    z-index:200;
}

.topnav h1{
    font-size:1.4rem;
    color:var(--primary);
}

.nav-actions button{
    background:var(--primary);
    border:none;
    color:white;
    padding:8px 14px;
    border-radius:6px;
    cursor:pointer;
}

/* ---------- MAIN ---------- */
.main{
    margin-left:260px;
    margin-top:80px;
    padding:20px;
    width:100%;
}

/* ---------- CARDS ---------- */
.stats{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(230px,1fr));
    gap:20px;
}

.card{
    background:var(--card);
    padding:20px;
    border-radius:10px;
    text-align:center;
    border-left:5px solid var(--primary);
}

/* ---------- CHARTS ---------- */
.chart-container{
    width:100%;
    max-width:420px;
    height:220px;
    margin:auto;
}

/* ---------- TABLES ---------- */
section{
    margin-top:40px;
}

section h2{
    margin-bottom:15px;
    color:var(--primary);
}

table{
    width:100%;
    background:var(--card);
    border-radius:10px;
    overflow:hidden;
    border-collapse:collapse;
}

th{
    background:var(--primary);
    color:white;
    padding:12px;
}

td{
    padding:12px;
    border-bottom:1px solid var(--border);
}

tr:hover td{
    background:rgba(0,0,0,0.07);
}

.action-btn{
    background:#1abc9c;
    padding:7px 14px;
    border-radius:6px;
    color:white !important;
    text-decoration:none;
}

/* ---------- MOBILE ---------- */
@media(max-width:850px){
    .sidebar{
        left:-260px;
    }
    .sidebar.show{
        left:0;
    }
    .topnav{
        left:0;
    }
    .main{
        margin-left:0;
    }
}
</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">
    <h2>Admin Menu</h2>
    <a href="index.php">Dashboard</a>
    <a href="#">Parents</a>
    <a href="#">Sitters</a>
    <a href="#">Bookings</a>
    <a href="#">Reports</a>
    <a href="logout.php">Logout</a>
</div>

<!-- TOP NAV -->
<div class="topnav">
    <h1>ChaguaSitter Admin</h1>
    <div class="nav-actions">
        <button id="themeToggle">Dark Mode</button>
        <button id="menuToggle">☰</button>
    </div>
</div>

<!-- MAIN -->
<div class="main">

    <!-- Stats -->
    <div class="stats">
        <div class="card"><h3>Total Parents</h3><p><?= $total_parents ?></p></div>
        <div class="card"><h3>Total Sitters</h3><p><?= $total_sitters ?></p></div>
        <div class="card"><h3>Total Bookings</h3><p><?= $total_bookings ?></p></div>
    </div>

    <!-- Charts -->
    <section>
        <h2>System Overview</h2>
        <div class="chart-container">
            <canvas id="overviewChart"></canvas>
        </div>
    </section>

    <section>
        <h2>Booking Status</h2>
        <div class="chart-container">
            <canvas id="statusChart"></canvas>
        </div>
    </section>

    <!-- Parents Table -->
    <section>
        <h2>Parents</h2>
        <table>
            <tr><th>ID</th><th>Name</th><th>Email</th><th>Location</th></tr>
            <?php mysqli_data_seek($parents,0); while($p=mysqli_fetch_assoc($parents)){ ?>
            <tr>
                <td><?= $p['parent_id'] ?></td>
                <td><?= $p['fullname'] ?></td>
                <td><?= $p['email'] ?></td>
                <td><?= $p['location'] ?></td>
            </tr>
            <?php } ?>
        </table>
    </section>

    <!-- Sitters Table -->
    <section>
        <h2>Sitters</h2>
        <table>
            <tr><th>ID</th><th>Name</th><th>Email</th><th>Experience</th><th>Action</th></tr>
            <?php mysqli_data_seek($sitters,0); while($s=mysqli_fetch_assoc($sitters)){ ?>
            <tr>
                <td><?= $s['sitter_id'] ?></td>
                <td><?= $s['fullname'] ?></td>
                <td><?= $s['email'] ?></td>
                <td><?= $s['experience'] ?> yrs</td>
                <td><a class="action-btn" href="impersonate.php?type=sitter&id=<?= $s['sitter_id'] ?>">View</a></td>
            </tr>
            <?php } ?>
        </table>
    </section>

    <!-- Parent Impersonation -->
    <section>
        <h2>Parent Impersonation</h2>
        <table>
            <tr><th>ID</th><th>Name</th><th>Email</th><th>Location</th><th>Action</th></tr>
            <?php mysqli_data_seek($parents,0); while($p=mysqli_fetch_assoc($parents)){ ?>
            <tr>
                <td><?= $p['parent_id'] ?></td>
                <td><?= $p['fullname'] ?></td>
                <td><?= $p['email'] ?></td>
                <td><?= $p['location'] ?></td>
                <td><a class="action-btn" href="impersonate.php?type=parent&id=<?= $p['parent_id'] ?>">View</a></td>
            </tr>
            <?php } ?>
        </table>
    </section>

</div>

<script>
document.getElementById("menuToggle").onclick = () => {
    document.getElementById("sidebar").classList.toggle("show");
};

// Theme toggle
const toggleBtn = document.getElementById("themeToggle");
const body = document.body;

if(localStorage.getItem("theme")==="dark"){
    body.classList.add("dark");
    toggleBtn.textContent="Light Mode";
}

toggleBtn.onclick = () => {
    body.classList.toggle("dark");
    toggleBtn.textContent = body.classList.contains("dark") ? "Light Mode" : "Dark Mode";
    localStorage.setItem("theme", body.classList.contains("dark") ? "dark" : "light");
};

// Charts (smaller size)
new Chart(document.getElementById("overviewChart"), {
    type:'bar',
    data:{
        labels:['Parents','Sitters','Bookings'],
        datasets:[{
            data:[<?= $total_parents ?>, <?= $total_sitters ?>, <?= $total_bookings ?>],
            backgroundColor:['#1cc88a','#f39c12','#e67e22']
        }]
    },
    options:{ responsive:true, maintainAspectRatio:false }
});

new Chart(document.getElementById("statusChart"), {
    type:'pie',
    data:{
        labels:['Pending','Approved','Completed','Cancelled'],
        datasets:[{ data:[<?= $pending ?>, <?= $approved ?>, <?= $completed ?>, <?= $cancelled ?>] }]
    },
    options:{ responsive:true, maintainAspectRatio:false }
});
</script>
<script src="script.js"></script>
</body>
</html>
