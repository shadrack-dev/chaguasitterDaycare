<?php
session_start();

// Only proceed if admin backup exists
if (isset($_SESSION['admin_backup'])) {
    // Restore the original admin session
    $_SESSION = $_SESSION['admin_backup'];
    unset($_SESSION['admin_backup']);      // remove backup
    unset($_SESSION['admin_impersonating']); // remove impersonation flag
}

// Redirect to admin dashboard
header("Location: index.php");
exit;
?>