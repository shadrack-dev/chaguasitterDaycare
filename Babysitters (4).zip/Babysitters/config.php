<?php
// =======================
// Admin Credentials
// =======================
$admin_email = "admin1@daycare.com";
$admin_password = "Sinda1234#"; // You can later hash it if needed

// =======================
// MPESA API CONFIGURATION
// =======================
$MPESA_CONSUMER_KEY    = "YOUR_CONSUMER_KEY";
$MPESA_CONSUMER_SECRET = "YOUR_CONSUMER_SECRET";

$MPESA_SHORTCODE = "174379"; // Paybill or Till
$MPESA_PASSKEY   = "YOUR_PASSKEY";

$MPESA_CALLBACK_URL = "https://yourdomain.com/mpesa_callback.php";

// JWT Secret Key
$JWT_SECRET = "your_super_secret_key_here"; // Use a long random string


?>
