<?php
header("Content-Type: application/json");

include "db_connect.php";

// Read Mpesa callback
$data = file_get_contents("php://input");
$callback = json_decode($data, true);

$checkoutRequestID = $callback["Body"]["stkCallback"]["CheckoutRequestID"];
$resultCode = $callback["Body"]["stkCallback"]["ResultCode"];

if ($resultCode == 0) {
    // Payment Success
    $meta = $callback["Body"]["stkCallback"]["CallbackMetadata"]["Item"];
    $amount = $meta[0]["Value"];
    $mpesaReceipt = $meta[1]["Value"];
    $phone = $meta[4]["Value"];

    $stmt = $conn->prepare("
        UPDATE payments 
        SET status='Completed', transaction_code=? 
        WHERE transaction_code=?
    ");
    $stmt->bind_param("ss", $mpesaReceipt, $checkoutRequestID);
    $stmt->execute();

} else {
    // Payment Failed
    $stmt = $conn->prepare("
        UPDATE payments 
        SET status='Failed' 
        WHERE transaction_code=?
    ");
    $stmt->bind_param("s", $checkoutRequestID);
    $stmt->execute();
}

// Respond to Mpesa
echo json_encode(["success" => true]);
?>
