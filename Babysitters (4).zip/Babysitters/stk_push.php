<?php
include 'mpesa_config.php';

$phone = $_POST['phone'];
$amount = $_POST['amount'];

$booking_id = $_POST['booking_id'];
$parent_id  = $_POST['parent_id'];
$sitter_id  = $_POST['sitter_id'];

$phone = "254" . substr($phone, -9);

// create dynamic callback url
$callback_url = "https://yourdomain.com/mpesa_callback.php?booking_id=$booking_id&parent_id=$parent_id&sitter_id=$sitter_id";

// generate token
$token_url = "https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials";
$curl = curl_init($token_url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_USERPWD, $mpesa_consumer_key . ":" . $mpesa_consumer_secret);
$response = json_decode(curl_exec($curl));
$token = $response->access_token;

$timestamp = date("YmdHis");
$password = base64_encode($shortcode . $passkey . $timestamp);

$stk_url = 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest';

$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $stk_url);
curl_setopt($curl, CURLOPT_HTTPHEADER, [
    'Content-Type:application/json',
    "Authorization: Bearer $token"
]);

$data = [
    "BusinessShortCode" => $shortcode,
    "Password" => $password,
    "Timestamp" => $timestamp,
    "TransactionType" => "CustomerPayBillOnline",
    "Amount" => $amount,
    "PartyA" => $phone,
    "PartyB" => $shortcode,
    "PhoneNumber" => $phone,
    "CallBackURL" => $callback_url,
    "AccountReference" => "Booking-$booking_id",
    "TransactionDesc" => "Payment for Sitter"
];

curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

echo curl_exec($curl);
curl_close($curl);
?>
