<?php
session_start();
include 'db_connect.php';
include 'config.php';

$error = $message = "";

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $email = trim($_POST['email'] ?? '');
    if (!$email) $error = "Enter your email.";
    else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email=? LIMIT 1");
        $stmt->bind_param("s",$email);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res && $res->num_rows===1) {
            $user = $res->fetch_assoc();
            $token = bin2hex(random_bytes(50));
            $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

            $stmt2 = $conn->prepare("INSERT INTO password_resets (user_id, token, expires_at) VALUES (?,?,?)");
            $stmt2->bind_param("iss",$user['id'],$token,$expiry);
            $stmt2->execute();

            $reset_link = "http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['REQUEST_URI'])."/reset_password.php?token=$token";

            // TODO: send email to user with $reset_link
            // For now just display link for testing
            $message = "Password reset link (valid 1 hour): <a href='".htmlspecialchars($reset_link)."'>Reset Password</a>";
        } else $error = "Email not found.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Forgot Password</title>
<style>
body{font-family:Poppins,sans-serif;background:#f4f6f8;display:flex;justify-content:center;align-items:center;height:100vh;margin:0;}
.box{background:#fff;padding:30px;border-radius:12px;box-shadow:0 6px 25px rgba(0,0,0,0.15);width:360px;text-align:center;}
.input{width:100%;padding:12px;margin:8px 0;border:1px solid #ccc;border-radius:8px;}
.btn{width:100%;padding:12px;background:#ff6f00;color:#fff;border:none;border-radius:8px;font-weight:600;cursor:pointer;}
.msg{font-size:14px;margin-top:10px;}
.error{color:#c62828;}
.success{color:#2e7d32;}
</style>
</head>
<body>
<div class="box">
<h2>Forgot Password</h2>
<form method="POST">
    <input type="email" class="input" name="email" placeholder="Enter your email" required>
    <button class="btn" type="submit">Send Reset Link</button>
</form>
<?php if($error) echo "<p class='msg error'>$error</p>"; ?>
<?php if($message) echo "<p class='msg success'>$message</p>"; ?>
</div>
<script src="script.js"></script>
</body>
</html>
