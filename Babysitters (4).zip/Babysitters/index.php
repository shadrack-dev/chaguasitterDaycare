<?php
session_start();
include 'db_connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Daycare | Find Trusted Babysitters</title>

<!-- Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" integrity="sha512-somehash" crossorigin="anonymous" referrerpolicy="no-referrer" />

<style>
/* ============= RESET ============= */
/* ============= RESET ============= */
*{ box-sizing:border-box; margin:0; padding:0; font-family:"Poppins",sans-serif; }

/* ============= THEME VARS ============= */
:root{
  --primary:#ff9800;
  --bg:#f5f6fa;
  --card:#ffffff;
  --text:#222;
  --muted:#8a8a8a;
  --sidebar-bg:#0f0f10;
  --glass: rgba(255,255,255,0.08);
  --glass-strong: rgba(255,255,255,0.12);
  --shadow: rgba(0,0,0,0.12);
  --transition: 250ms cubic-bezier(.2,.9,.3,1);
}

/* DARK MODE VARS */
body.dark{
  --bg:#0b0b0c;
  --card:#141414;
  --text:#eee;
  --muted:#cfcfcf;
  --glass: rgba(0,0,0,0.45);
  --glass-strong: rgba(0,0,0,0.6);
  --sidebar-bg:#080808;
}

/* ============= GLOBAL BACKGROUND IMAGE ============= */
body {
  height: 100%;
  background: url('images/daycare-bg.jpg') center/cover fixed no-repeat;
  color: var(--text);
  -webkit-font-smoothing: antialiased;
  position: relative;
}

body::before {
  content: "";
  position: fixed;
  top: 0; left: 0;
  width: 100%; height: 100%;
  background: rgba(0,0,0,0.35);
  z-index: -1;
  pointer-events: none;
}

body.dark::before {
  background: rgba(0,0,0,0.55);
}

/* ============= LAYOUT ============= */
html,body{ height:100%; }

/* (Your remaining layout styles stay unchanged) */

.app {
  min-height:100vh;
  display:flex;
  overflow-x:hidden;
}

/* ============= SIDEBAR ============= */
.sidebar {
  width:260px;
  min-width:260px;
  background:var(--sidebar-bg);
  color: #fff;
  height:100vh;
  position:fixed;
  left:0;
  top:0;
  padding:22px 16px;
  display:flex;
  flex-direction:column;
  gap:12px;
  transform:translateX(0);
  transition: transform var(--transition);
  z-index:1000;
  box-shadow: 0 8px 30px rgba(0,0,0,0.35);
  border-right: 3px solid var(--primary);
}

.sidebar.collapsed{ transform:translateX(-320px); }

.brand {
  display:flex;
  align-items:center;
  gap:12px;
  padding-bottom:8px;
  border-bottom:1px solid rgba(255,255,255,0.04);
}

.brand .logo {
  width:42px; height:42px; border-radius:10px;
  background: linear-gradient(135deg,var(--primary), #ffb86b);
  display:flex; align-items:center; justify-content:center; color:#fff; font-weight:700;
  box-shadow: 0 4px 14px rgba(0,0,0,0.2);
}

.brand h2{ font-size:1.05rem; color:var(--primary); }

/* Sidebar nav */
.nav {
  margin-top:10px;
  display:flex;
  flex-direction:column;
  gap:6px;
  padding-top:6px;
  overflow:auto;
}

.nav a{
  display:flex;
  gap:12px;
  align-items:center;
  color: #e6e6e6;
  text-decoration:none;
  padding:10px 12px;
  border-radius:10px;
  transition: background var(--transition), transform var(--transition);
  font-weight:600;
}

.nav a i{ width:22px; text-align:center; font-size:0.95rem; color:var(--primary); }
.nav a:hover{ background: rgba(255,255,255,0.03); transform:translateX(4px); color:#fff; }
.nav a.active{ background: linear-gradient(90deg,var(--primary), #ffb86b); color:#111; font-weight:700; }

/* bottom area (logout etc.) */
.sidebar .bottom {
  margin-top:auto;
  padding-top:12px;
  border-top:1px solid rgba(255,255,255,0.04);
  display:flex;
  flex-direction:column;
  gap:8px;
}

/* ============= MAIN AREA ============= */
.main {
  margin-left:260px;
  width:calc(100% - 260px);
  transition: margin-left var(--transition), width var(--transition);
  min-height:100vh;
  display:flex;
  flex-direction:column;
}

/* when sidebar collapsed */
.main.expanded{ margin-left:0; width:100%; }

/* TOPBAR */
.topbar{
  position:sticky;
  top:0;
  z-index:500;
  display:flex;
  justify-content:space-between;
  align-items:center;
  gap:12px;
  padding:14px 20px;
  background: linear-gradient(180deg,var(--card), rgba(255,255,255,0));
  border-bottom:1px solid rgba(0,0,0,0.04);
  backdrop-filter: blur(6px);
}

.topbar .left { display:flex; align-items:center; gap:12px; }
.hamburger {
  display:inline-flex;
  align-items:center;
  justify-content:center;
  width:44px; height:44px;
  background:var(--glass);
  border-radius:10px;
  border: none;
  cursor:pointer;
  color:var(--text);
  transition:transform var(--transition);
}

.hamburger:hover{ transform:scale(1.03); }

/* search */
.search {
  display:flex;
  gap:10px;
  align-items:center;
  background:var(--card);
  border-radius:10px;
  padding:8px 10px;
  box-shadow: 0 6px 18px var(--shadow);
}

.search input{
  border:0; outline:0; background:transparent; color:var(--text); font-weight:600;
}

/* actions */
.actions { display:flex; gap:10px; align-items:center; }

/* theme toggle */
.theme-btn{
  background:var(--primary);
  color:#111;
  border:none;
  padding:8px 12px;
  border-radius:10px;
  font-weight:700;
  cursor:pointer;
}

/* ============= HERO ============= */
.hero .card {
  max-width:720px;
  width:100%;
  background: rgba(0,0,0,0.45);
  padding:40px;
  border-radius:20px;
  text-align:center;
  backdrop-filter: blur(8px);
  border:1px solid rgba(255,255,255,0.15);
  box-shadow: 0 12px 40px rgba(0,0,0,0.4);
}


.hero .card {
  max-width:720px;
  width:100%;
  background: linear-gradient(180deg, var(--glass-strong), rgba(255,255,255,0.02));
  padding:36px;
  border-radius:16px;
  text-align:center;
  border:1px solid rgba(255,255,255,0.06);
  box-shadow: 0 10px 30px rgba(0,0,0,0.12);
}

.hero h1 { font-size:2.4rem; margin-bottom:10px; color:var(--primary); }
.hero p { font-size:1.05rem; color:var(--muted); margin-bottom:18px; }

.btn {
  background:var(--primary);
  color:#111;
  border:0;
  padding:12px 22px;
  border-radius:999px;
  font-weight:800;
  cursor:pointer;
  box-shadow: 0 8px 18px rgba(0,0,0,0.12);
}

/* sitters grid (white section) */
.section {
  background: rgba(255,255,255,0.85);
  backdrop-filter: blur(6px);
  padding:40px;
  border-radius:14px;
  margin:20px 28px;
  box-shadow: 0 8px 26px rgba(0,0,0,0.06);
}

body.dark .section {
  background: rgba(0,0,0,0.6);
}


/* filter */
.filter-box {
  display:flex;
  gap:12px;
  flex-wrap:wrap;
  justify-content:center;
  margin-bottom:24px;
}

.filter-box input, .filter-box select {
  padding:10px 12px;
  border-radius:10px;
  border:1px solid #ddd;
  min-width:160px;
}

/* sitters grid */
.sitters-grid {
  display:grid;
  gap:20px;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
}

.sitter-card {
  background: #fff;
  border-radius:12px;
  overflow:hidden;
  box-shadow:0 8px 20px rgba(0,0,0,0.06);
  transition: transform var(--transition), box-shadow var(--transition);
  text-align:center;
  padding-bottom:14px;
}

.sitter-card img{ width:100%; height:200px; object-fit:cover; display:block; }
.sitter-card h3{ margin:12px 8px; color:var(--text); }
.sitter-card p{ margin-bottom:6px; color:var(--muted); font-weight:600; }
.sitter-card .small-btn{
  margin-top:8px;
  background:var(--primary);
  color:#111;
  border:0;
  padding:8px 14px;
  border-radius:999px;
  cursor:pointer;
  font-weight:700;
}

/* responsive adjustments */
@media (max-width: 900px) {
  .sidebar{ position:fixed; transform:translateX(-320px); }
  .sidebar.open{ transform:translateX(0); }
  .main{ margin-left:0; width:100%; }
  .hamburger{ display:inline-flex; }
  .brand h2{ font-size:1rem; }
  .hero { padding:18px; margin:18px 12px 6px 12px; }
  .section{ margin:12px; padding:20px; }
}

/* small details */
a,button{ outline: none; }
</style>
</head>
<body>

<div class="app">

  <!-- SIDEBAR -->
  <aside class="sidebar" id="sidebar">
    <div class="brand">
      <div class="logo">DS</div>
      <div>
        <h2>Daycare</h2>
        <div style="font-size:0.8rem; color:rgba(255,255,255,0.7)">Find Babysitters</div>
      </div>
    </div>

    <nav class="nav" role="navigation" aria-label="Main Navigation">
      <a href="index.php" class="active"><i class="fa fa-home"></i> Dashboard</a>
      <a href="explore_sitters.php"><i class="fa fa-user-group"></i> Explore Sitters</a>
      <a href="manage_bookings.php"><i class="fa fa-calendar-check"></i> Bookings</a>
      <a href="manage_parents.php"><i class="fa fa-user"></i> Parents</a>
      <a href="manage_sitters.php"><i class="fa fa-id-badge"></i> Sitters</a>
      <a href="feedback.html"><i class="fa fa-comments"></i> Feedback</a>
      <a href="about.html"><i class="fa fa-circle-info"></i> About</a>
      <a href="contact.html"><i class="fa fa-envelope"></i> Contact</a>
    </nav>

    <div class="bottom">
      <a href="admin_login.php"><i class="fa fa-user-shield"></i> Administrator</a>
      <a href="logout.php"><i class="fa fa-right-from-bracket"></i> Logout</a>
    </div>
  </aside>

  <!-- MAIN -->
  <main class="main" id="main">
    <!-- TOPBAR -->
    <div class="topbar">
      <div class="left">
        <button class="hamburger" id="hamburger" aria-label="Toggle menu"><i class="fa fa-bars"></i></button>

        <div style="display:flex; flex-direction:column;">
          <div style="font-size:0.95rem; font-weight:800">Welcome back</div>
          <div style="font-size:0.82rem; color:var(--muted)">Manage your daycare platform</div>
        </div>
      </div>

      <div class="actions">
        <div class="search" role="search" aria-label="Site search">
          <i class="fa fa-magnifying-glass" style="color:var(--muted)"></i>
          <input id="globalSearch" placeholder="Search sitters, bookings..." aria-label="Search" />
        </div>

        <button id="themeToggle" class="theme-btn" title="Toggle dark mode">Dark</button>
      </div>
    </div>

    <!-- HERO -->
    <section class="hero">
      <div class="card hero-card">
        <h1>Find Trusted Babysitters Near You</h1>
        <p>Connecting parents with verified babysitters for safe, stress-free childcare services.</p>
        <button class="btn" onclick="document.getElementById('explore-section').scrollIntoView({behavior:'smooth'})"><i class="fa fa-magnifying-glass"></i> Explore Sitters</button>
      </div>
    </section>

    <!-- EXPLORE / SITTERS -->
    <section id="explore-section" class="section" aria-labelledby="explore-heading" >
      <h2 id="explore-heading" style="color:var(--primary); margin-bottom:14px">Explore Sitters</h2>

      <div class="filter-box" style="margin-bottom:18px;">
        <input id="filterLocation" type="text" placeholder="Location" />
        <select id="filterAvailability">
          <option value="">Any Availability</option>
          <option value="available">Available</option>
          <option value="unavailable">Unavailable</option>
        </select>

        <select id="filterRateType">
          <option value="">Any Rate Type</option>
          <option value="hourly">Hourly</option>
          <option value="daily">Daily</option>
          <option value="weekly">Weekly</option>
        </select>

        <button class="small-btn" onclick="loadSitters()" style="background:var(--primary); color:#111; border-radius:10px; padding:10px 14px; font-weight:800; border:0;">
          <i class="fa fa-filter"></i> Filter
        </button>
      </div>

      <div id="sittersGrid" class="sitters-grid" aria-live="polite">
        <!-- Sitters loaded here via JS -->
      </div>
    </section>

    <!-- ABOUT -->
    <section class="section" style="margin-top:16px;">
      <h2 style="color:var(--primary); margin-bottom:12px;">About Our Daycare Platform</h2>
      <p style="color:var(--muted); max-width:900px;">
        Our platform is designed to connect parents with trusted, verified babysitters in their local area.
        We prioritize safety, professionalism, and convenience—making childcare easier and stress-free.
        Whether you need hourly, daily, or weekly help, our sitters are carefully screened and rated by real parents.
      </p>
    </section>

    <footer style="margin:20px 28px 40px; color:var(--muted); text-align:center;">
      &copy; <?php echo date("Y"); ?> Daycare | All Rights Reserved
    </footer>
  </main>
</div>

<!-- ============= SCRIPTS ============= -->
<script>
/* SIDEBAR & HAMBURGER BEHAVIOR */
const sidebar = document.getElementById('sidebar');
const hamburger = document.getElementById('hamburger');
const main = document.getElementById('main');

/* persist sidebar state */
const savedSidebar = localStorage.getItem('sidebarOpen');
if(window.innerWidth <= 900){
  // on small screens default closed unless user opened previously
  if(savedSidebar === 'true') sidebar.classList.add('open');
  else sidebar.classList.remove('open');
} else {
  // desktop: ensure visible
  sidebar.classList.remove('collapsed');
  main.classList.remove('expanded');
}

/* toggle function */
function toggleSidebar(){
  if(window.innerWidth <= 900){
    // mobile slide behavior
    const isOpen = sidebar.classList.toggle('open');
    localStorage.setItem('sidebarOpen', isOpen ? 'true' : 'false');
  } else {
    // desktop collapse
    sidebar.classList.toggle('collapsed');
    main.classList.toggle('expanded');
  }
}

/* connect both hamburger & sidebar toggle */
hamburger.addEventListener('click', toggleSidebar);
document.querySelectorAll('.nav a').forEach(a=>{
  a.addEventListener('click', ()=> {
    if(window.innerWidth <= 900){
      // auto close after selecting on mobile
      sidebar.classList.remove('open');
      localStorage.setItem('sidebarOpen','false');
    }
  });
});

/* close sidebar when clicking outside on mobile */
document.addEventListener('click', (e)=>{
  if(window.innerWidth <= 900){
    if(!sidebar.contains(e.target) && !hamburger.contains(e.target)){
      sidebar.classList.remove('open');
    }
  }
});

/* THEME TOGGLE */
const themeToggle = document.getElementById('themeToggle');
const body = document.body;
const savedTheme = localStorage.getItem('theme') || (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');

if(savedTheme === 'dark') body.classList.add('dark'), themeToggle.textContent='Light';
else body.classList.remove('dark'), themeToggle.textContent='Dark';

themeToggle.addEventListener('click', ()=>{
  body.classList.toggle('dark');
  const isDark = body.classList.contains('dark');
  themeToggle.textContent = isDark ? 'Light' : 'Dark';
  localStorage.setItem('theme', isDark ? 'dark' : 'light');
});

/* GLOBAL SEARCH - basic client-side filter for loaded sitters */
document.getElementById('globalSearch').addEventListener('input', function(e){
  const q = e.target.value.toLowerCase();
  document.querySelectorAll('.sitter-card').forEach(card=>{
    const txt = card.innerText.toLowerCase();
    card.style.display = txt.includes(q) ? 'block' : 'none';
  });
});

/* FETCH SITTERS - uses fetch_sitters.php (same as your original) */
function loadSitters(){
  const loc = encodeURIComponent(document.getElementById('filterLocation').value || '');
  const availability = encodeURIComponent(document.getElementById('filterAvailability').value || '');
  const rateType = encodeURIComponent(document.getElementById('filterRateType').value || '');
  const grid = document.getElementById('sittersGrid');
  grid.innerHTML = '<div style="grid-column:1/-1;padding:24px;text-align:center;color:var(--muted)">Loading sitters...</div>';

  fetch(`fetch_sitters.php?location=${loc}&availability=${availability}&rate_type=${rateType}`)
    .then(res => res.json())
    .then(data => {
      if(!Array.isArray(data) || data.length === 0){
        grid.innerHTML = '<div style="grid-column:1/-1;padding:24px;text-align:center;color:var(--muted)">No sitters found.</div>';
        return;
      }

      const html = data.map(s => {
        // use JSON.stringify to safely encode fullname into onclick
        const photo = s.profile_photo ? s.profile_photo : 'images/default-profile.png';
        return `
          <div class="sitter-card" role="article" aria-label="${s.fullname}">
            <img src="${photo}" alt="${s.fullname} profile photo" loading="lazy" />
            <h3>${escapeHtml(s.fullname)}</h3>
            <p>Location: ${escapeHtml(s.location || 'N/A')}</p>
            <p>Experience: ${escapeHtml(String(s.experience || '0'))} years</p>
            <p>Rate: ${escapeHtml(String(s.rate_amount || '0'))} (${escapeHtml(s.rate_type || '-')})</p>
            <p>Availability: ${escapeHtml(s.availability || '-')}</p>
            <button class="small-btn" onclick='addToCart(${Number(s.sitter_id)}, ${JSON.stringify(s.fullname)})'>
              <i class="fa fa-cart-plus"></i> Add to Booking
            </button>
          </div>
        `;
      }).join('');
      grid.innerHTML = html;
    })
    .catch(err => {
      console.error(err);
      grid.innerHTML = '<div style="grid-column:1/-1;padding:24px;text-align:center;color:var(--muted)">Error loading sitters.</div>';
    });
}

/* addToCart - stores simple booking cart in localStorage */
function addToCart(id, name){
  try {
    const key = 'bookingCart';
    let cart = JSON.parse(localStorage.getItem(key) || '[]');
    if(cart.find(x => x.sitter_id === id)){
      alert(name + ' is already in your booking cart.');
      return;
    }
    cart.push({sitter_id: id, fullname: name});
    localStorage.setItem(key, JSON.stringify(cart));
    alert(name + ' added to your booking cart.');
  } catch(e){
    console.error(e);
    alert('Unable to add to cart.');
  }
}

/* simple HTML escape to avoid accidental markup being inserted */
function escapeHtml(unsafe){
  return (unsafe+'').replace(/[&<>"'`]/g, function(m){
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;', '`':'&#096;'}[m];
  });
}

/* load sitters on initial page load */
document.addEventListener('DOMContentLoaded', function(){
  loadSitters();
  // restore sidebar state for desktop: collapsed key can be used if desired
  const desktopCollapsed = localStorage.getItem('desktopCollapsed') === 'true';
  if(window.innerWidth > 900 && desktopCollapsed){
    sidebar.classList.add('collapsed');
    main.classList.add('expanded');
  }
});

/* optional: persist desktop collapse toggle */
sidebar.addEventListener('transitionend', ()=> {
  if(window.innerWidth > 900){
    localStorage.setItem('desktopCollapsed', sidebar.classList.contains('collapsed') ? 'true' : 'false');
  }
});
</script>
<script src="script.js"></script>
</body>
</html>
