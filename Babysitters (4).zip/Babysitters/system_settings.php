<?php
session_start();
include('db_connect.php');

// --- Restrict access to admin only ---
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Fetch settings
$query = "SELECT * FROM system_settings LIMIT 1";
$result = $conn->query($query);
$settings = $result->fetch_assoc();

// --- Update system settings ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_settings'])) {
    $system_name = trim($_POST['system_name']);
    $admin_email = trim($_POST['admin_email']);
    $rate_per_child = floatval($_POST['rate_per_child']);
    $updated_at = date('Y-m-d H:i:s');

    if ($settings) {
        $stmt = $conn->prepare("UPDATE system_settings SET system_name=?, admin_email=?, rate_per_child=?, updated_at=? WHERE id=?");
        $stmt->bind_param('ssdsi', $system_name, $admin_email, $rate_per_child, $updated_at, $settings['id']);
    } else {
        $stmt = $conn->prepare("INSERT INTO system_settings (system_name, admin_email, rate_per_child, updated_at) VALUES (?, ?, ?, ?)");
        $stmt->bind_param('ssds', $system_name, $admin_email, $rate_per_child, $updated_at);
    }

    if ($stmt->execute()) {
        echo "<script>alert('System settings updated successfully!'); window.location='system_settings.php';</script>";
    } else {
        echo "<script>alert('Error updating settings. Please try again.');</script>";
    }
    $stmt->close();
}

// --- Update admin password ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_password'])) {
    $new_pass = trim($_POST['new_password']);
    $confirm_pass = trim($_POST['confirm_password']);

    if ($new_pass !== $confirm_pass) {
        echo "<script>alert('Passwords do not match!');</script>";
    } elseif (strlen($new_pass) < 6) {
        echo "<script>alert('Password must be at least 6 characters long!');</script>";
    } else {
        $new_hash = password_hash($new_pass, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE admin_accounts SET password=? WHERE role='admin'");
        $stmt->bind_param('s', $new_hash);
        if ($stmt->execute()) {
            echo "<script>alert('Admin password updated successfully!'); window.location='system_settings.php';</script>";
        } else {
            echo "<script>alert('Error updating password.');</script>";
        }
        $stmt->close();
    }
}

// --- Test Email Functionality ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['test_email'])) {
    $to = trim($_POST['admin_email']);
    $subject = "ChaguaSitter - Test Email";
    $message = "Hello Admin,\n\nThis is a test email from the ChaguaSitter system.\n\nIf you received this, your email configuration is working.";
    $headers = "From: noreply@chaguasitter.com";

    if (mail($to, $subject, $message, $headers)) {
        echo "<script>alert('Test email sent successfully to: $to');</script>";
    } else {
        echo "<script>alert('Failed to send test email. Please check your server email settings.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>System Settings | ChaguaSitter</title>
<style>
body {
    font-family: 'Poppins', sans-serif;
    background: #f0f2f5;
    margin: 0;
}
.wrapper { display: flex; min-height: 100vh; }
.sidebar {
    width: 220px;
    background-color: #ff6f00;
    color: white;
    display: flex;
    flex-direction: column;
    padding-top: 30px;
}
.sidebar h2 {
    text-align: center;
    margin-bottom: 30px;
    font-size: 22px;
}
.sidebar a {
    color: white;
    text-decoration: none;
    padding: 15px 20px;
    display: block;
    transition: 0.3s;
}
.sidebar a:hover, .sidebar a.active { background-color: #e65c00; }
.main-content { flex: 1; padding: 40px; }
h1 {
    color: #ff6f00;
    text-align: center;
    margin-bottom: 30px;
}
.section {
    background: white;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1);
    max-width: 600px;
    margin: 0 auto 40px auto;
}
.section h2 {
    color: #333;
    margin-bottom: 20px;
    border-bottom: 2px solid #ff6f00;
    padding-bottom: 8px;
}
label {
    font-weight: 600;
    display: block;
    margin-bottom: 8px;
    color: #333;
}
input {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
    border-radius: 8px;
    border: 1px solid #ccc;
    font-size: 15px;
}
input:focus {
    outline: none;
    border-color: #ff6f00;
    box-shadow: 0 0 6px rgba(255,111,0,0.4);
}
.password-container { position: relative; }
.toggle-password {
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    font-size: 14px;
    color: #ff6f00;
    user-select: none;
}
button {
    width: 100%;
    background: #ff6f00;
    color: white;
    border: none;
    padding: 12px;
    border-radius: 10px;
    font-size: 16px;
    cursor: pointer;
    font-weight: bold;
    transition: background 0.3s;
    margin-bottom: 10px;
}
button:hover { background: #e65c00; }
footer {
    text-align: center;
    padding: 20px;
    background: #333;
    color: white;
    font-size: 14px;
    margin-top: 40px;
}
@media (max-width: 768px) {
    .wrapper { flex-direction: column; }
    .sidebar { width: 100%; flex-direction: row; overflow-x: auto; }
    .sidebar a { flex: 1; text-align: center; }
}
</style>
</head>
<body>
<div class="wrapper">
    <div class="sidebar">
        <h2>ChaguaSitter</h2>
        <a href="Admin_Dashboard.php">Dashboard</a>
        <a href="manage_users.php">Manage Users</a>
        <a href="system_settings.php" class="active">System Settings</a>
        <a href="logout.php">Logout</a>
    </div>

    <div class="main-content">
        <h1>System Settings</h1>

        <!-- System Settings Section -->
        <form method="POST" class="section">
            <h2>General Settings</h2>
            <label>System Name</label>
            <input type="text" name="system_name" value="<?= htmlspecialchars($settings['system_name'] ?? 'ChaguaSitter Babysitting System') ?>" required>

            <label>Admin Email</label>
            <input type="email" name="admin_email" value="<?= htmlspecialchars($settings['admin_email'] ?? '') ?>" required>

            <label>Rate per Child (KES)</label>
            <input type="number" step="0.01" name="rate_per_child" value="<?= htmlspecialchars($settings['rate_per_child'] ?? 0) ?>" required>

            <button type="submit" name="update_settings">Save Settings</button>
            <button type="submit" name="test_email" style="background:#4CAF50;">Send Test Email</button>
        </form>

        <!-- Admin Password Section -->
        <form method="POST" class="section">
            <h2>Change Admin Password</h2>

            <label>New Password</label>
            <div class="password-container">
                <input type="password" id="new_password" name="new_password" required>
                <span class="toggle-password" onclick="togglePassword('new_password', this)">Show</span>
            </div>

            <label>Confirm Password</label>
            <div class="password-container">
                <input type="password" id="confirm_password" name="confirm_password" required>
                <span class="toggle-password" onclick="togglePassword('confirm_password', this)">Show</span>
            </div>

            <button type="submit" name="update_password">Update Password</button>
        </form>
    </div>
</div>

<footer>&copy; <?= date('Y'); ?> ChaguaSitter. All Rights Reserved.</footer>

<script>
function togglePassword(id, el) {
    const input = document.getElementById(id);
    if (input.type === "password") {
        input.type = "text";
        el.textContent = "Hide";
    } else {
        input.type = "password";
        el.textContent = "Show";
    }
}
</script>
<script src="script.js"></script>
</body>
</html>
