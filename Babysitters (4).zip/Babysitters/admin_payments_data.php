<?php
session_start();
include "db_connect.php";

if(!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in']!==true){
    http_response_code(401);
    exit;
}

$filter = "";
if(isset($_GET['status']) && $_GET['status'] != ""){
    $status_filter = $_GET['status'];
    $filter = "WHERE status='$status_filter'";
}

$result = $conn->query("SELECT * FROM payments $filter ORDER BY created_at DESC");

$payments = [];
while($row = $result->fetch_assoc()){
    $payments[] = $row;
}

echo json_encode($payments);
?>
