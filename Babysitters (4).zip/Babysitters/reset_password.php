<?php
session_start();
include 'db_connect.php';
$error = $message = "";

$token = $_GET['token'] ?? '';

if (!$token) { $error = "Invalid token."; }

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm'] ?? '';

    if (!$password || !$confirm) $error = "Both fields required.";
    elseif ($password !== $confirm) $error = "Passwords do not match.";
    elseif (strlen($password)<6) $error = "Password must be at least 6 characters.";
    else {
        $stmt = $conn->prepare("SELECT user_id, expires_at FROM password_resets WHERE token=? LIMIT 1");
        $stmt->bind_param("s",$token);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res && $res->num_rows===1) {
            $row = $res->fetch_assoc();
            if (strtotime($row['expires_at']) < time()) $error = "Token expired.";
            else {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt2 = $conn->prepare("UPDATE users SET password=? WHERE id=?");
                $stmt2->bind_param("si",$hash,$row['user_id']);
                $stmt2->execute();

                // Delete token
                $stmt3 = $conn->prepare("DELETE FROM password_resets WHERE token=?");
                $stmt3->bind_param("s",$token);
                $stmt3->execute();

                $message = "Password reset successfully. <a href='login.php'>Login now</a>.";
            }
        } else $error = "Invalid token.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Reset Password</title>
<style>
body{font-family:Poppins,sans-serif;background:#f4f6f8;display:flex;justify-content:center;align-items:center;height:100vh;margin:0;}
.box{background:#fff;padding:30px;border-radius:12px;box-shadow:0 6px 25px rgba(0,0,0,0.15);width:360px;text-align:center;}
.input{width:100%;padding:12px;margin:8px 0;border:1px solid #ccc;border-radius:8px;}
.btn{width:100%;padding:12px;background:#ff6f00;color:#fff;border:none;border-radius:8px;font-weight:600;cursor:pointer;}
.msg{font-size:14px;margin-top:10px;}
.error{color:#c62828;}
.success{color:#2e7d32;}
.password-wrapper{position:relative;}
.toggle-password{position:absolute;right:15px;top:50%;transform:translateY(-50%);cursor:pointer;user-select:none;}
</style>
</head>
<body>
<div class="box">
<h2>Reset Password</h2>
<?php if(!$error) { ?>
<form method="POST">
    <div class="password-wrapper">
        <input type="password" class="input" name="password" placeholder="New Password" required id="password">
        <span class="toggle-password" id="togglePass">👁️</span>
    </div>
    <input type="password" class="input" name="confirm" placeholder="Confirm Password" required>
    <button class="btn" type="submit">Reset Password</button>
</form>
<?php } ?>
<?php if($error) echo "<p class='msg error'>$error</p>"; ?>
<?php if($message) echo "<p class='msg success'>$message</p>"; ?>
</div>

<script>
const toggle = document.getElementById('togglePass');
const passwordInput = document.getElementById('password');
toggle.addEventListener('click',()=>{
    if(passwordInput.type==='password'){passwordInput.type='text';toggle.textContent='🙈';}
    else{passwordInput.type='password';toggle.textContent='👁️';}
});
</script>
<script src="script.js"></script>
</body>
</html>
