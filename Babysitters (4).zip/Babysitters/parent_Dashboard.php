<?php 
session_start();
include 'db_connect.php';

// Ensure the user is logged in as a parent
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'parent') {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch parent details
$query = "SELECT p.*, u.fullname, u.email 
          FROM parents p 
          JOIN users u ON p.user_id = u.id 
          WHERE p.user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$parent = $result->fetch_assoc();

if (!$parent) {
    $parent = [
        'fullname' => 'Parent',
        'email' => 'Not available',
        'phone' => 'Not available',
        'address' => 'Not available'
    ];
}

// Fetch bookings
$bookingsQuery = "SELECT b.*, s.sitter_id, u.fullname AS sitter_name 
                  FROM bookings b 
                  JOIN sitters s ON b.sitter_id = s.sitter_id 
                  JOIN users u ON s.user_id = u.id 
                  WHERE b.parent_id = (SELECT parent_id FROM parents WHERE user_id = ?)";
$stmt2 = $conn->prepare($bookingsQuery);
$stmt2->bind_param("i", $user_id);
$stmt2->execute();
$bookings = $stmt2->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Parent Dashboard | ChaguaSitter</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>

:root {
    --primary: #2b6777;
    --primary-light: #52ab98;
    --bg: #f5f7fa;
    --card-bg: #ffffff;
    --text: #333;
    --sidebar-bg: #1f3f49;
}

body.dark {
    --bg: #121212;
    --card-bg: #1e1e1e;
    --text: #eaeaea;
    --sidebar-bg: #0d1f24;
}

/* GENERAL */
body {
    margin: 0;
    font-family: "Poppins", sans-serif;
    background: var(--bg);
    color: var(--text);
    transition: 0.3s;
    display: flex;
}

/* SIDEBAR */
.sidebar {
    width: 250px;
    height: 100vh;
    background: var(--sidebar-bg);
    color: #ffffff;
    position: fixed;
    top: 0;
    left: 0;
    padding-top: 20px;
    transition: 0.3s;
}

.sidebar h2 {
    text-align: center;
    margin-bottom: 20px;
    color: var(--primary-light);
}

.sidebar a {
    display: block;
    padding: 14px 20px;
    color: #fff;
    text-decoration: none;
    font-size: 1em;
    transition: 0.3s;
}

.sidebar a:hover,
.sidebar a.active {
    background: var(--primary-light);
}

/* PAGE CONTENT */
.main-content {
    margin-left: 250px;
    width: calc(100% - 250px);
    transition: 0.3s;
}

/* NAVBAR */
.navbar {
    background: var(--primary);
    padding: 15px 30px;
    color: #fff;
    display:flex;
    justify-content: space-between;
    align-items: center;
}

.navbar a {
    color: #fff;
    text-decoration: none;
    margin-left: 20px;
    font-weight: 500;
}

.navbar a:hover {
    color: var(--primary-light);
}

.theme-btn {
    background: var(--primary-light);
    border: none;
    padding: 7px 15px;
    border-radius: 6px;
    cursor: pointer;
    color: #fff;
}

/* CONTAINER */
.dashboard-container {
    max-width: 1100px;
    margin: 30px auto;
    padding: 15px;
}

/* CARDS */
.card {
    background: var(--card-bg);
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.09);
    margin-bottom: 25px;
}

.card h3 {
    margin-top: 0;
    color: var(--primary);
    border-left: 4px solid var(--primary-light);
    padding-left: 10px;
}

/* STATS */
.stat-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px,1fr));
    gap: 15px;
    margin-top: 20px;
}

.stat-box {
    background: var(--primary);
    color: #fff;
    padding: 18px;
    border-radius: 10px;
    text-align: center;
    font-size: 1.1em;
}

.stat-box span {
    font-size: 1.7em;
    font-weight: 600;
}

/* TABLE */
table {
    width:100%;
    border-collapse: collapse;
    margin-top: 15px;
}

th, td {
    padding: 12px;
    text-align: left;
}

th {
    background: var(--primary);
    color:#fff;
}

tr:nth-child(even) {
    background: rgba(0,0,0,0.04);
}

/* BUTTON */
.btn {
    background: var(--primary-light);
    padding: 7px 15px;
    text-decoration: none;
    color:#fff;
    border-radius: 6px;
}

.btn:hover {
    background: #3f8b79;
}

/* FOOTER */
footer {
    text-align:center;
    padding: 15px;
    background: var(--primary);
    color:#fff;
    margin-top: 30px;
    font-size: 0.9em;
}

@media(max-width: 900px) {
    .sidebar {
        width: 200px;
    }
    .main-content {
        margin-left: 200px;
    }
}

@media(max-width:700px) {
    .sidebar {
        left: -260px;
    }
    .sidebar.active {
        left: 0;
    }
    .main-content {
        margin-left: 0;
        width: 100%;
    }
}

</style>

</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">
    <h2>Parent Menu</h2>
    <a href="parent_Dashboard.php" class="active">🏠 Dashboard</a>
    <a href="add_booking.php">📝 Add Booking</a>
    <a href="profile.php">👤 Profile</a>
    <a href="logout.php">🚪 Logout</a>
</div>

<!-- MAIN CONTENT -->
<div class="main-content">

    <!-- NAVBAR -->
    <div class="navbar">
        <button style="background:none;border:none;color:white;font-size:1.5em;cursor:pointer;" id="toggleBtn">☰</button>

        <strong style="font-size:1.4em;">ChaguaSitter</strong>

        <button class="theme-btn" id="themeToggle">🌙 Dark Mode</button>
    </div>

    <div class="dashboard-container">

        <!-- Parent Info -->
        <div class="card">
            <h3>Welcome, <?php echo htmlspecialchars($parent['fullname']); ?></h3>
            <p><strong>Email:</strong> <?php echo $parent['email']; ?></p>
            <p><strong>Phone:</strong> <?php echo $parent['phone']; ?></p>
            <p><strong>Address:</strong> <?php echo $parent['address']; ?></p>
        </div>

        <!-- Stats -->
        <div class="stat-grid">
            <div class="stat-box">Bookings<br><span><?php echo $bookings->num_rows; ?></span></div>
            <div class="stat-box">Completed<br><span>
                <?php 
                    $c = 0;
                    foreach ($bookings as $b) { if ($b["status"] == "completed") $c++; }
                    echo $c; 
                ?>
            </span></div>
            <div class="stat-box">Pending<br><span>
                <?php 
                    $p = 0;
                    foreach ($bookings as $b) { if ($b["status"] == "pending") $p++; }
                    echo $p; 
                ?>
            </span></div>
        </div>

        <!-- Bookings Table -->
        <div class="card">
            <h3>My Bookings</h3>

            <?php if ($bookings->num_rows > 0) { ?>
            <table>
                <tr>
                    <th>Sitter</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>

                <?php foreach ($bookings as $row) { ?>
                <tr>
                    <td><?php echo $row['sitter_name']; ?></td>
                    <td><?php echo $row['booking_date']; ?></td>
                    <td><?php echo $row['start_time']." - ".$row['end_time']; ?></td>
                    <td><?php echo ucfirst($row['status']); ?></td>
                    <td>
                        <?php if ($row['status']=="completed") { ?>
                            <a class="btn" href="review.php?booking_id=<?php echo $row['booking_id']; ?>">Review</a>
                        <?php } else { ?>
                            <a class="btn" href="confirm_booking.php?id=<?php echo $row['booking_id']; ?>">Cancel</a>
                        <?php } ?>
                    </td>
                </tr>
                <?php } ?>
            </table>

            <?php } else { ?>
                <p style="color:var(--primary)">No bookings yet. <a href="add_booking.php">Add a booking</a></p>
            <?php } ?>
        </div>

    </div>

    <footer>
        © <?php echo date("Y"); ?> ChaguaSitter. All Rights Reserved.
    </footer>

</div>

<script>
// SIDEBAR TOGGLE (MOBILE)
const toggleBtn = document.getElementById("toggleBtn");
const sidebar = document.getElementById("sidebar");

toggleBtn.addEventListener("click", () => {
    sidebar.classList.toggle("active");
});

// Dark Mode
const body = document.body;
const themeToggle = document.getElementById("themeToggle");

if (localStorage.getItem("theme") === "dark") {
    body.classList.add("dark");
    themeToggle.textContent = "☀ Light Mode";
}

themeToggle.addEventListener("click", () => {
    body.classList.toggle("dark");
    const isDark = body.classList.contains("dark");
    themeToggle.textContent = isDark ? "☀ Light Mode" : "🌙 Dark Mode";
    localStorage.setItem("theme", isDark ? "dark" : "light");
});
</script>
<script src="script.js"></script>
</body>
</html>
