<?php
session_start();

if (!isset($_SESSION['admin_viewing'])) {
    die("Unauthorized");
}

$user = $_SESSION['view_profile'];
$type = $_SESSION['view_type'];
?>

<h2>Viewing <?= ucfirst($type) ?> Profile</h2>

<p><strong>Name:</strong> <?= $user['fullname'] ?></p>
<p><strong>Email:</strong> <?= $user['email'] ?></p>

<?php if ($type === 'parent'): ?>
<p><strong>Phone:</strong> <?= $user['phone'] ?></p>
<p><strong>Address:</strong> <?= $user['address'] ?></p>
<?php else: ?>
<p><strong>Phone:</strong> <?= $user['phone'] ?></p>
<p><strong>Experience:</strong> <?= $user['experience'] ?> years</p>
<p><strong>Rate:</strong> <?= $user['rate_amount'] ?></p>
<?php endif; ?>
