<?php
header('Content-Type: application/json');

include "db_connect.php";
include "config.php";

// Get data from request
$data = json_decode(file_get_contents("php://input"), true);

$phone = $data["phone"];
$amount = $data["amount"];
$booking_id = $data["booking_id"];
$parent_id = $data["parent_id"];
$sitter_id = $data["sitter_id"];

// Generate Access Token
$tokenUrl = "https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials";
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $tokenUrl);
curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($curl, CURLOPT_USERPWD, $MPESA_CONSUMER_KEY . ":" . $MPESA_CONSUMER_SECRET);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
$tokenResponse = curl_exec($curl);
curl_close($curl);

$accessToken = json_decode($tokenResponse)->access_token;

// Prepare STK Push
$timestamp = date("YmdHis");
$password = base64_encode($MPESA_SHORTCODE . $MPESA_PASSKEY . $timestamp);

$stkUrl = "https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest";

$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $stkUrl);
curl_setopt($curl, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "Authorization: Bearer " . $accessToken
]);

$payload = [
    "BusinessShortCode" => $MPESA_SHORTCODE,
    "Password" => $password,
    "Timestamp" => $timestamp,
    "TransactionType" => "CustomerPayBillOnline",
    "Amount" => $amount,
    "PartyA" => $phone,
    "PartyB" => $MPESA_SHORTCODE,
    "PhoneNumber" => $phone,
    "CallBackURL" => $MPESA_CALLBACK_URL,
    "AccountReference" => "Babysitting",
    "TransactionDesc" => "Payment"
];

curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($curl);
curl_close($curl);

$responseData = json_decode($response, true);

// Insert payment record with Pending status
$stmt = $conn->prepare("
    INSERT INTO payments (booking_id, parent_id, sitter_id, amount, payment_method, status, transaction_code)
    VALUES (?, ?, ?, ?, 'Mpesa', 'Pending', ?)
");
$stmt->bind_param("iiids", $booking_id, $parent_id, $sitter_id, $amount, $responseData["CheckoutRequestID"]);
$stmt->execute();

echo json_encode([
    "success" => true,
    "message" => "STK push initiated",
    "CheckoutRequestID" => $responseData["CheckoutRequestID"]
]);
?>
