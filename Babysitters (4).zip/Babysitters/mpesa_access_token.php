<?php
include "config.php";

// Generate Access Token
$url = "https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials";

$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($curl, CURLOPT_USERPWD, $MPESA_CONSUMER_KEY . ":" . $MPESA_CONSUMER_SECRET);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($curl);
curl_close($curl);

$result = json_decode($response);

if(isset($result->access_token)){
    echo $result->access_token;
} else {
    echo json_encode(["success"=>false, "message"=>"Failed to get access token"]);
}
?>
