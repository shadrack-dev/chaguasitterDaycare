<?php
session_start();
include('db_connect.php');

// Only admins
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
  header("Location: login.php");
  exit();
}

// Handle sitter actions
if(isset($_GET['action']) && isset($_GET['id'])){
  $id = $_GET['id'];
  $action = $_GET['action'];

  if($action == 'activate'){
    mysqli_query($conn, "UPDATE sitters SET availability='available' WHERE sitter_id='$id'");
  } elseif($action == 'deactivate'){
    mysqli_query($conn, "UPDATE sitters SET availability='unavailable' WHERE sitter_id='$id'");
  } elseif($action == 'delete'){
    mysqli_query($conn, "DELETE FROM sitters WHERE sitter_id='$id'");
  }

  header("Location: manage_sitters.php");
  exit();
}

// Fetch sitters with their details
$query = "
  SELECT s.*, u.fullname, u.email 
  FROM sitters s
  JOIN users u ON s.user_id = u.id
  ORDER BY s.sitter_id DESC
";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Sitters | ChaguaSitter</title>
<style>
  body { font-family: 'Poppins', sans-serif; background: #f7f7f7; margin: 0; }
  .container { width: 92%; margin: 40px auto; background: white; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); padding: 25px; }
  h2 { text-align: center; color: #333; }
  table { width: 100%; border-collapse: collapse; margin-top: 20px; }
  th, td { padding: 12px; border-bottom: 1px solid #ddd; }
  th { background: #ff9900; color: white; text-align: left; }
  tr:hover { background: #fff3e0; }
  .actions a { margin-right: 8px; padding: 7px 12px; border-radius: 5px; text-decoration: none; font-size: 13px; }
  .activate { background: #28a745; color: white; }
  .deactivate { background: #dc3545; color: white; }
  .delete { background: #6c757d; color: white; }
  .topbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
  .topbar a { color: #ff9900; text-decoration: none; font-weight: 600; }
  input { padding: 8px; width: 220px; border-radius: 6px; border: 1px solid #ccc; }
</style>
<script>
function confirmAction(type, name){
  return confirm("Are you sure you want to " + type + " sitter " + name + "?");
}

function filterSitters(){
  let filter = document.getElementById("searchInput").value.toLowerCase();
  let rows = document.querySelectorAll("tbody tr");
  rows.forEach(row => {
    let text = row.textContent.toLowerCase();
    row.style.display = text.includes(filter) ? "" : "none";
  });
}
</script>
</head>
<body>
<div class="container">
  <div class="topbar">
    <h2>Manage Sitters</h2>
    <a href="Admin_Dashboard.php">← Back to Dashboard</a>
  </div>

  <input type="text" id="searchInput" onkeyup="filterSitters()" placeholder="Search sitter...">

  <table>
    <thead>
      <tr>
        <th>#</th>
        <th>Full Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Experience (yrs)</th>
        <th>Rate (Ksh/hr)</th>
        <th>Status</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php $count=1; while($row = mysqli_fetch_assoc($result)): ?>
      <tr>
        <td><?php echo $count++; ?></td>
        <td><?php echo htmlspecialchars($row['fullname']); ?></td>
        <td><?php echo htmlspecialchars($row['email']); ?></td>
        <td><?php echo htmlspecialchars($row['phone']); ?></td>
        <td><?php echo htmlspecialchars($row['experience']); ?></td>
        <td><?php echo htmlspecialchars($row['hourly_rate']); ?></td>
        <td><?php echo ucfirst($row['availability']); ?></td>
        <td class="actions">
          <?php if($row['availability'] == 'unavailable'): ?>
            <a href="?action=activate&id=<?php echo $row['sitter_id']; ?>" class="activate" onclick="return confirmAction('activate','<?php echo $row['fullname']; ?>')">Activate</a>
          <?php else: ?>
            <a href="?action=deactivate&id=<?php echo $row['sitter_id']; ?>" class="deactivate" onclick="return confirmAction('deactivate','<?php echo $row['fullname']; ?>')">Deactivate</a>
          <?php endif; ?>
          <a href="?action=delete&id=<?php echo $row['sitter_id']; ?>" class="delete" onclick="return confirmAction('delete','<?php echo $row['fullname']; ?>')">Delete</a>
        </td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>
<script src="script.js"></script>
</body>
</html>
