<?php
session_start();
include('db_connect.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$sql = "SELECT fullname, role FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$fullname = htmlspecialchars($user['fullname']);
$role = htmlspecialchars($user['role']);

// SITTER DASHBOARD DATA
if ($role === 'sitter') {
    $stmt = $conn->prepare("
        SELECT s.sitter_id, s.phone, s.experience, s.bio, s.hourly_rate, 
               s.availability, s.profile_photo, u.email
        FROM sitters s
        JOIN users u ON s.user_id = u.id
        WHERE s.user_id = ?
    ");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $sitter = $stmt->get_result()->fetch_assoc();
    $sitter_id = $sitter['sitter_id'];

    $earnings = $conn->query("
        SELECT 
            SUM(CASE WHEN status='Completed' THEN amount END) AS total_earned,
            SUM(CASE WHEN status='Pending' THEN amount END) AS pending_payment,
            COUNT(CASE WHEN status='Completed' THEN 1 END) AS completed_bookings
        FROM payments
        WHERE booking_id IN (SELECT booking_id FROM bookings WHERE sitter_id = $sitter_id)
    ")->fetch_assoc();

    $upcoming = $conn->query("
        SELECT b.booking_id, b.booking_date, b.start_time, b.end_time, b.status,
               u.fullname AS parent_name
        FROM bookings b
        JOIN parents p ON b.parent_id = p.parent_id
        JOIN users u ON p.user_id = u.id
        WHERE b.sitter_id = $sitter_id AND b.booking_date >= CURDATE()
        ORDER BY b.booking_date ASC
        LIMIT 5
    ");

    $rating = $conn->query("
        SELECT ROUND(AVG(r.rating),1) AS avg_rating, COUNT(*) AS total_reviews
        FROM reviews r
        JOIN bookings b ON r.booking_id = b.booking_id
        WHERE b.sitter_id = $sitter_id
    ")->fetch_assoc();

    $fields = [$sitter['phone'],$sitter['experience'],$sitter['hourly_rate'],$sitter['bio'],$sitter['availability'],$sitter['profile_photo']];
    $filled = count(array_filter($fields));
    $profile_percent = round(($filled / count($fields)) * 100);

    $notifications = $conn->query("
        SELECT COUNT(*) AS total
        FROM bookings
        WHERE sitter_id = $sitter_id AND status='pending'
    ")->fetch_assoc();

    $calendar_events = [];
    $res = $conn->query("SELECT b.booking_id, b.booking_date, b.start_time, b.end_time, b.status, u.fullname AS parent_name 
                         FROM bookings b 
                         JOIN parents p ON b.parent_id = p.parent_id
                         JOIN users u ON p.user_id = u.id
                         WHERE b.sitter_id=$sitter_id");
    while($row=$res->fetch_assoc()){
        $calendar_events[]=[
            'id'=>$row['booking_id'],
            'title'=>$row['parent_name'].' ('.$row['status'].')',
            'start'=>$row['booking_date'].'T'.$row['start_time'],
            'end'=>$row['booking_date'].'T'.$row['end_time'],
            'status'=>$row['status']
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Dashboard | ChaguaSitter</title>
<link rel="stylesheet" href="style.css" />
<?php if($role==='sitter'): ?>
<link href='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/main.min.css' rel='stylesheet' />
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/main.min.js'></script>
<?php endif; ?>
<style>
body{font-family:"Poppins",sans-serif;margin:0;background:#f4f4f4;color:#333;}
header{background:rgba(0,0,0,0.6);color:white;padding:15px 30px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;}
main{padding:20px;margin:20px auto;max-width:1100px;}
nav a{margin:0 10px;text-decoration:none;color:#3498db;font-weight:bold;cursor:pointer;}
nav a.active{color:#ff6f00;}
.section{display:none;margin-top:20px;}
.section.active{display:block;}
.card-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:20px;margin-bottom:30px;}
.card{background:white;padding:25px;border-radius:12px;box-shadow:0 6px 15px rgba(0,0,0,0.08);text-align:center;position:relative;}
.card h3{color:#ff6f00;margin-bottom:10px;}
.progress{width:100%;background:#eee;height:12px;border-radius:8px;overflow:hidden;margin-top:10px;}
.progress-bar{height:12px;background:#28a745;transition:width 0.5s;}
.toggle-btn{padding:10px 18px;border:none;border-radius:6px;cursor:pointer;font-weight:600;color:white;}
.available{background:#28a745;} .busy{background:#dc3545;} .onleave{background:#ffc107;color:#333;}
table{width:100%;border-collapse:collapse;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 4px 12px rgba(0,0,0,0.05);}
th,td{padding:12px;border-bottom:1px solid #ccc;text-align:left;}
th{background:#ff6f00;color:white;}
#calendar{background:white;padding:15px;border-radius:12px;box-shadow:0 4px 12px rgba(0,0,0,0.05);margin-top:30px;}
</style>
</head>
<body>

<header>
  <h2>Welcome, <?= $fullname ?> 👋</h2>
  <div><span class="role-badge"><?= ucfirst($role) ?></span><a href="logout.php">Logout</a></div>
</header>

<main>
<nav>
<?php if($role==='parent'): ?>
  <a class="tab-link active" data-target="tab-home">Home</a>
  <a class="tab-link" data-target="tab-sitters">View Sitters</a>
  <a class="tab-link" data-target="tab-bookings">My Bookings</a>
<?php elseif($role==='sitter'): ?>
  <a class="tab-link active" data-target="tab-home">Home</a>
  <a class="tab-link" data-target="tab-earnings">Earnings</a>
  <a class="tab-link" data-target="tab-bookings">Assigned Jobs</a>
  <a class="tab-link" data-target="tab-calendar">Calendar</a>
<?php elseif($role==='admin'): ?>
  <a class="tab-link active" data-target="tab-home">Home</a>
  <a class="tab-link" data-target="tab-users">Manage Users</a>
  <a class="tab-link" data-target="tab-bookings">Manage Bookings</a>
<?php endif; ?>
</nav>

<!-- Home Section -->
<div id="tab-home" class="section active">
  <h1><?= ucfirst($role) ?> Dashboard</h1>
  <p>Welcome to your dashboard. Click the tabs above to navigate without leaving this page.</p>
</div>

<?php if($role==='parent'): ?>
<div id="tab-sitters" class="section">
  <h2>Available Sitters</h2>
  <p>List of sitters with booking option here.</p>
</div>
<div id="tab-bookings" class="section">
  <h2>My Bookings</h2>
  <p>All your bookings will appear here.</p>
</div>
<?php elseif($role==='sitter'): ?>
<div id="tab-earnings" class="section">
  <div class="card-grid">
    <div class="card"><h3>Total Earnings</h3><p>Ksh <?=number_format($earnings['total_earned'] ?? 0)?></p></div>
    <div class="card"><h3>Pending Payments</h3><p>Ksh <?=number_format($earnings['pending_payment'] ?? 0)?></p></div>
    <div class="card"><h3>Completed Bookings</h3><p><?= $earnings['completed_bookings'] ?? 0 ?></p></div>
    <div class="card"><h3>Rating</h3><p><?= $rating['avg_rating'] ?? 0 ?> ⭐ (<?= $rating['total_reviews']?> reviews)</p></div>
    <div class="card"><h3>Notifications</h3><p><?= $notifications['total'] ?> New</p></div>
    <div class="card"><h3>Availability</h3>
      <button id="availabilityBtn" class="toggle-btn <?= $sitter['availability']=='available'?'available':($sitter['availability']=='busy'?'busy':'onleave')?>"><?= ucfirst($sitter['availability'])?></button>
    </div>
    <div class="card" style="grid-column:1/-1;"><h3>Profile Completion</h3>
      <div class="progress"><div class="progress-bar" style="width:<?=$profile_percent?>%"></div></div>
    </div>
  </div>
</div>
<div id="tab-bookings" class="section">
  <h2>Upcoming Bookings</h2>
  <table>
    <tr><th>Parent</th><th>Date</th><th>Time</th><th>Status</th></tr>
    <?php while($b=$upcoming->fetch_assoc()): ?>
      <tr>
        <td><?=htmlspecialchars($b['parent_name'])?></td>
        <td><?=$b['booking_date']?></td>
        <td><?=$b['start_time'].' - '.$b['end_time']?></td>
        <td><?=ucfirst($b['status'])?></td>
      </tr>
    <?php endwhile; ?>
  </table>
</div>
<div id="tab-calendar" class="section">
  <h2>Booking Calendar</h2>
  <div id="calendar"></div>
</div>
<?php endif; ?>

</main>

<footer>&copy; <?= date("Y") ?> ChaguaSitter</footer>

<script>
const tabs=document.querySelectorAll('.tab-link');
const sections=document.querySelectorAll('.section');
tabs.forEach(tab=>{
    tab.addEventListener('click',()=>{
        tabs.forEach(t=>t.classList.remove('active'));
        tab.classList.add('active');
        let target=tab.getAttribute('data-target');
        sections.forEach(s=>s.classList.remove('active'));
        document.getElementById(target).classList.add('active');
    });
});

// Sitter availability toggle
<?php if($role==='sitter'): ?>
const btn=document.getElementById('availabilityBtn');
btn.addEventListener('click',()=>{
    let current=btn.textContent.toLowerCase();
    let states=['available','busy','on leave'];
    let nextIndex=(states.indexOf(current)+1)%states.length;
    let newState=states[nextIndex];
    fetch("update_availability.php",{
        method:"POST",
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:"availability="+encodeURIComponent(newState)
    }).then(res=>res.json()).then(data=>{
        if(data.status==='success'){
            btn.textContent=data.availability.charAt(0).toUpperCase()+data.availability.slice(1);
            btn.className='toggle-btn '+(data.availability=='available'?'available':(data.availability=='busy'?'busy':'onleave'));
        } else { alert('Failed to update availability.'); }
    });
});

// FullCalendar
document.addEventListener('DOMContentLoaded', function() {
    var calendarEl=document.getElementById('calendar');
    var calendar=new FullCalendar.Calendar(calendarEl,{
        initialView:'dayGridMonth',
        headerToolbar:{left:'prev,next today',center:'title',right:''},
        events: <?= json_encode($calendar_events) ?>,
    });
    calendar.render();
});
<?php endif; ?>
</script>
<script src="script.js"></script>
</body>
</html>
