<?php
session_start();
include 'db_connect.php';

// Ensure parent is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'parent') {
    header("Location: login.php");
    exit();
}

// Get the correct parent_id from parents table
$user_id = $_SESSION['user_id'];
$parentQuery = $conn->prepare("SELECT parent_id FROM parents WHERE user_id = ?");
$parentQuery->bind_param("i", $user_id);
$parentQuery->execute();
$parentResult = $parentQuery->get_result();

if ($parentResult->num_rows === 0) {
    die(" Parent record not found. Please complete your profile first.");
}

$parent = $parentResult->fetch_assoc();
$parent_id = $parent['parent_id'];

$message = "";

// Handle booking
if (isset($_POST['submit'])) {
    $sitter_id = $_POST['sitter_id'];
    $booking_date = $_POST['booking_date'];

    // Check sitter availability
    $check = $conn->prepare("SELECT availability, fullname FROM sitters WHERE sitter_id = ?");
    $check->bind_param("i", $sitter_id);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        $sitter = $result->fetch_assoc();

        $status = ($sitter['availability'] == 1) ? 'approved' : 'rejected';

        // Insert booking
        $insert = $conn->prepare("INSERT INTO bookings (parent_id, sitter_id, booking_date, status) VALUES (?, ?, ?, ?)");
        $insert->bind_param("iiss", $parent_id, $sitter_id, $booking_date, $status);

        if ($insert->execute()) {
            // Update sitter availability if approved
            if ($status === 'approved') {
                $conn->query("UPDATE sitters SET availability = 0 WHERE sitter_id = $sitter_id");
                $message = " Booking approved successfully! Sitter: " . htmlspecialchars($sitter['fullname']);
            } else {
                $message = " Booking rejected. Sitter not available.";
            }

            // Send notification
            $notify = $conn->prepare("INSERT INTO notifications (parent_id, message, is_ready) VALUES (?, ?, 0)");
            $notify->bind_param("is", $parent_id, $message);
            $notify->execute();

        } else {
            $message = " Booking failed: " . $insert->error;
        }

    } else {
        $message = "Invalid sitter ID.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Book a Sitter | ChaguaSitter</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
body {
    font-family: 'Poppins', sans-serif;
    background: #f4f6f9;
    margin: 0;
}
.container {
    max-width: 450px;
    margin: 60px auto;
    background: #fff;
    border-radius: 12px;
    padding: 30px 25px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.08);
}
h2 {
    text-align: center;
    margin-bottom: 25px;
    color: #ff6f00;
}
form input, form button {
    width: 100%;
    margin-bottom: 15px;
    padding: 12px 15px;
    border-radius: 8px;
    border: 1px solid #ddd;
    font-size: 1em;
}
form input:focus {
    border-color: #ff6f00;
    outline: none;
}
button {
    background: #ff6f00;
    color: white;
    border: none;
    cursor: pointer;
    font-weight: 600;
    transition: 0.3s;
}
button:hover {
    background: #e55b00;
}
.message {
    text-align: center;
    margin-top: 15px;
    font-weight: 500;
}
.success { color: green; }
.error { color: red; }
</style>
</head>
<body>
<div class="container">
    <h2>Book a Sitter</h2>
    <form method="POST">
        <input type="number" name="sitter_id" placeholder="Enter Sitter ID" required>
        <input type="date" name="booking_date" required>
        <button type="submit" name="submit">Book Now</button>
    </form>

    <?php if ($message): ?>
        <p class="message <?php echo (strpos($message,'approved')!==false) ? 'success' : 'error'; ?>">
            <?php echo $message; ?>
        </p>
    <?php endif; ?>
</div>
<script src="script.js"></script>
</body>
</html>
