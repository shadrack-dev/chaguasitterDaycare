<?php
session_start();
include "db_connect.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$booking_id = isset($_GET['booking_id']) ? intval($_GET['booking_id']) : 0;

if($booking_id <= 0){
    die("Invalid booking ID");
}

// Handle review submission
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['rating']) && isset($_POST['comment'])){
    $rating = intval($_POST['rating']);
    $comment = trim($_POST['comment']);

    $stmt = $conn->prepare("INSERT INTO reviews (booking_id, user_id, rating, comment, created_at) VALUES (?, ?, ?, ?, NOW())");
    $stmt->bind_param("iiis", $booking_id, $user_id, $rating, $comment);
    $stmt->execute();
    $success = "Review submitted successfully!";
}

// Fetch existing reviews
$stmt = $conn->prepare("
    SELECT r.*, u.fullname AS reviewer_name
    FROM reviews r
    JOIN users u ON r.user_id = u.id
    WHERE r.booking_id=?
    ORDER BY r.created_at DESC
");
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Booking Reviews</title>
<style>
/* General styles */
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 20px;
    background-color: #f9f9f9;
}
.container {
    max-width: 900px;
    margin: auto;
}

/* Review cards */
.review-box {
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    padding: 15px 20px;
    margin-bottom: 15px;
    transition: transform 0.2s;
}
.review-box:hover {
    transform: translateY(-2px);
}
.review-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.reviewer-name {
    font-weight: bold;
    color: #333;
}
.review-date {
    font-size: 0.85em;
    color: #888;
}
.rating {
    color: #ffb400;
    font-weight: bold;
}

/* Form styles */
.review-form {
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    margin-top: 25px;
}
.review-form h3 {
    margin-top: 0;
}
textarea, select {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    margin-bottom: 15px;
    border-radius: 5px;
    border: 1px solid #ccc;
    font-size: 1em;
}
button {
    background-color: #007BFF;
    color: #fff;
    border: none;
    padding: 12px 20px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 1em;
    transition: background-color 0.2s;
}
button:hover {
    background-color: #0056b3;
}
.success {
    color: green;
    font-weight: bold;
    margin-bottom: 15px;
}
</style>
</head>
<body>
<div class="container">
    <h1>Reviews for Booking #<?php echo $booking_id; ?></h1>

    <?php if(isset($success)) echo "<p class='success'>$success</p>"; ?>

    <!-- Display reviews -->
    <?php while($row = $result->fetch_assoc()): ?>
    <div class="review-box">
        <div class="review-header">
            <span class="reviewer-name"><?php echo htmlspecialchars($row['reviewer_name']); ?></span>
            <span class="rating">⭐ <?php echo $row['rating']; ?>/5</span>
        </div>
        <p><?php echo htmlspecialchars($row['comment']); ?></p>
        <div class="review-date"><?php echo $row['created_at']; ?></div>
    </div>
    <?php endwhile; ?>

    <!-- Submit review form -->
    <div class="review-form">
        <h3>Submit Your Review</h3>
        <form method="POST">
            <label>Rating:</label>
            <select name="rating" required>
                <option value="">Select rating</option>
                <?php for($i=1;$i<=5;$i++): ?>
                    <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                <?php endfor; ?>
            </select>
            <label>Comment:</label>
            <textarea name="comment" placeholder="Write your review here..." required></textarea>
            <button type="submit">Submit Review</button>
        </form>
    </div>
</div>
<script src="script.js"></script>
</body>
</html>
