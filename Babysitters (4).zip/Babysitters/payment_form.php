<form action="stk_push.php" method="POST">
    
    <input type="hidden" name="booking_id" value="<?php echo $booking_id; ?>">
    <input type="hidden" name="parent_id" value="<?php echo $parent_id; ?>">
    <input type="hidden" name="sitter_id" value="<?php echo $sitter_id; ?>">

    <label>Phone</label>
    <input type="text" name="phone" required>

    <label>Amount</label>
    <input type="number" name="amount" required value="<?php echo $amount; ?>">

    <button type="submit">Pay with Mpesa</button>
</form>
