<?php
header("Content-Type: application/json");
include "db_connect.php";
include "config.php";

$data = json_decode(file_get_contents("php://input"), true);

$id              = $data['payment_id'];
$status          = $data['status'];
$transaction_code = $data['transaction_code'];
$payment_method  = $data['payment_method'];

$sql = "UPDATE payments SET status = ?, transaction_code = ?, payment_method = ?
        WHERE payment_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("sssi", $status, $transaction_code, $payment_method, $id);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Payment updated successfully"]);
} else {
    echo json_encode(["success" => false, "message" => "Update failed"]);
}
?>
