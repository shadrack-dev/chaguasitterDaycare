<?php
session_start();
include 'db_connect.php';

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Check if sitter profile already exists
$checkQuery = "SELECT * FROM sitters WHERE user_id = ?";
$stmt = $conn->prepare($checkQuery);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    header("Location: sitter_dashboard.php");
    exit();
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $phone = $_POST['phone'];
    $experience = $_POST['experience'];
    $hourly_rate = $_POST['hourly_rate'];
    $availability = $_POST['availability'];
    $bio = $_POST['bio'];

    $insertQuery = "INSERT INTO sitters (user_id, phone, experience, hourly_rate, availability, bio)
                    VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($insertQuery);
    $stmt->bind_param("isidss", $user_id, $phone, $experience, $hourly_rate, $availability, $bio);

    if ($stmt->execute()) {
        echo "<script>
                alert('Sitter profile created successfully!');
                window.location.href = 'sitter_dashboard.php';
              </script>";
        exit();
    } else {
        $error = "Error: Could not create sitter profile. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register as Sitter | ChaguaSitter</title>
  <style>
    body {
      font-family: "Poppins", sans-serif;
      background: url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQB92zpQH3zWnhvFR1WyI5K8KjNsRa6JdxLdw&s') no-repeat center center/cover;
      margin: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .register-container {
      background: rgba(255, 255, 255, 0.95);
      padding: 30px 40px;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.3);
      width: 400px;
      text-align: center;
    }

    h2 {
      color: #f68b1e;
      margin-bottom: 20px;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }

    input, select, textarea {
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 14px;
      width: 100%;
    }

    textarea {
      resize: none;
      height: 80px;
    }

    button {
      background-color: #f68b1e;
      color: white;
      padding: 10px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-weight: bold;
      transition: background 0.3s;
    }

    button:hover {
      background-color: #e67e1e;
    }

    .error {
      color: red;
      margin-bottom: 10px;
    }

    .footer-text {
      margin-top: 15px;
      font-size: 14px;
    }

    .footer-text a {
      color: #f68b1e;
      text-decoration: none;
      font-weight: 500;
    }

    .footer-text a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<div class="register-container">
  <h2>Register as a Sitter 🧡</h2>

  <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>

  <form action="" method="POST">
    <input type="text" name="phone" placeholder="Phone Number" required>
    <input type="number" name="experience" placeholder="Years of Experience" min="0" required>
    <input type="number" name="hourly_rate" placeholder="Hourly Rate (Ksh)" min="0" required>
    
    <select name="availability" required>
      <option value="">-- Select Availability --</option>
      <option value="full-time">Full Time</option>
      <option value="part-time">Part Time</option>
      <option value="weekends">Weekends Only</option>
    </select>

    <textarea name="bio" placeholder="Write a short bio about yourself..." required></textarea>

    <button type="submit">Create Profile</button>
  </form>

  <div class="footer-text">
    <p>Already registered? <a href="sitter_dashboard.php">Go to Dashboard</a></p>
  </div>
</div>
<script src="script.js"></script>
</body>
</html>
