<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'parent') {
    header('Location: index.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch parent ID
$stmt = $conn->prepare("SELECT parent_id FROM parents WHERE user_id = ?");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$parent = $stmt->get_result()->fetch_assoc();
if (!$parent) die("Parent not found.");

$parent_id = $parent['parent_id'];

// Daily booking limits
$parent_daily_limit = 3;
$system_daily_limit = 20;
$today = date('Y-m-d');

// Count today's bookings
$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM bookings WHERE parent_id = ? AND DATE(booking_date) = ?");
$stmt->bind_param('is', $parent_id, $today);
$stmt->execute();
$pCount = $stmt->get_result()->fetch_assoc()['c'];

// Count system bookings
$stmt = $conn->prepare("SELECT COUNT(*) AS t FROM bookings WHERE DATE(booking_date) = ?");
$stmt->bind_param('s', $today);
$stmt->execute();
$sCount = $stmt->get_result()->fetch_assoc()['t'];

// Slots left
$slots_left = min(max(0, $parent_daily_limit - $pCount), max(0, $system_daily_limit - $sCount));
$limitReached = ($slots_left <= 0);

function getProgressColor($percentage){
    if($percentage < 30) return '#f44336';
    elseif($percentage < 70) return '#ff9800';
    else return '#4caf50';
}

$parent_progress = round(($pCount / $parent_daily_limit) * 100);
$system_progress = round(($sCount / $system_daily_limit) * 100);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Booking | ChaguaSitter</title>
<style>
body{font-family:'Poppins',sans-serif;background:#f8f8f8;margin:0;padding:0;}
header{background:#f68b1e;color:#fff;padding:15px 40px;display:flex;justify-content:space-between;align-items:center;}
header a{color:#fff;text-decoration:none;}
.container{max-width:700px;margin:40px auto;background:#fff;padding:25px;border-radius:12px;box-shadow:0 5px 15px rgba(0,0,0,0.1);}
h2{text-align:center;color:#f68b1e;margin-bottom:25px;}
.notice{background:#fff3e0;border-left:5px solid #f68b1e;padding:12px 15px;border-radius:6px;margin-bottom:20px;color:#444;font-size:15px;text-align:center;}
.slots{background:#e0f7fa;border-left:5px solid #00acc1;padding:10px 15px;border-radius:6px;margin-bottom:10px;font-size:15px;text-align:center;font-weight:600;color:#007c91;}
.progress-container{background:#eee;border-radius:10px;overflow:hidden;height:20px;margin-bottom:20px;}
.progress-bar{height:100%;text-align:center;color:#fff;line-height:20px;font-size:12px;}
form label{display:block;margin-top:15px;margin-bottom:5px;font-weight:600;}
form select, form input[type=date], form input[type=number], form textarea{
    width:100%;padding:10px;border-radius:6px;border:1px solid #ddd;font-size:14px;
}
textarea{min-height:80px;resize:vertical;}
.btn{margin-top:20px;background:#f68b1e;color:#fff;border:none;padding:12px 20px;border-radius:6px;width:100%;cursor:pointer;font-size:15px;}
.btn:hover{background:#e67e1e;}
footer{text-align:center;color:#fff;background:#f68b1e;padding:12px;margin-top:40px;font-size:13px;}
</style>
</head>
<body>

<header>
<h2>🧡ChaguaSitter | Add Booking</h2>
<nav><a href="my_bookings.php">Back</a></nav>
</header>

<div class="container">
<h2>New Booking</h2>

<?php if ($limitReached): ?>
  <div class="notice">Booking limit reached. Try again tomorrow.</div>
<?php else: ?>
  <div class="slots">Your Slots Left Today: <?= max(0, $parent_daily_limit - $pCount) ?></div>
  <div class="progress-container">
    <div class="progress-bar" style="width:<?= $parent_progress ?>%; background: <?= getProgressColor($parent_progress) ?>;">
      <?= $parent_progress ?>%
    </div>
  </div>

  <div class="slots">System Slots Left Today: <?= max(0, $system_daily_limit - $sCount) ?></div>
  <div class="progress-container">
    <div class="progress-bar" style="width:<?= $system_progress ?>%; background: <?= getProgressColor($system_progress) ?>%;">
      <?= $system_progress ?>%
    </div>
  </div>

  <form method="POST" action="process_booking.php">
      <label>Select Sitter:</label>
      <select name="sitter_id" required>
        <option value="">-- Choose Sitter --</option>
        <?php
        $sitters = $conn->query("SELECT s.sitter_id, u.fullname FROM sitters s JOIN users u ON s.user_id=u.id ORDER BY u.fullname");
        while ($s = $sitters->fetch_assoc()) {
          echo "<option value='{$s['sitter_id']}'>" . htmlspecialchars($s['fullname']) . "</option>";
        }
        ?>
      </select>

      <label>Booking Date:</label>
      <input type="date" name="booking_date" required min="<?= date('Y-m-d') ?>">

      <label>Duration (hours):</label>
      <input type="number" name="duration" required min="1" max="12">

      <label>Child Conditions / Notes:</label>
      <textarea name="child_conditions" placeholder="E.g., allergies, medical conditions, feeding routines..." required></textarea>

      <button type="submit" class="btn">Confirm Booking</button>
  </form>
<?php endif; ?>
</div>

<footer>© <?= date("Y") ?> ChaguaSitter. All rights reserved.</footer>
<script src="script.js"></script>
</body>
</html>
