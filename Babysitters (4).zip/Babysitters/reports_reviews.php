<?php
session_start();
include('db_connect.php');

// Ensure only admin can access
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("Access denied. Only admin can manage reviews.");
}

// --- Fetch Total Reviews ---
$totalReviews = intval(mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) AS total FROM reviews"))['total']);

// --- Fetch Top-Rated Sitters ---
$topSittersResult = mysqli_query($conn,"
    SELECT us.fullname AS sitter_name, ROUND(AVG(r.rating),2) AS avg_rating, COUNT(r.review_id) AS total_reviews
    FROM reviews r
    JOIN bookings b ON r.booking_id = b.booking_id
    JOIN sitters s ON b.sitter_id = s.sitter_id
    JOIN users us ON s.user_id = us.id
    GROUP BY s.sitter_id
    HAVING total_reviews>0
    ORDER BY avg_rating DESC
    LIMIT 5
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin | Manage Reviews</title>
<style>
body { font-family:'Poppins',sans-serif; margin:0; background:#f4f4f9; color:#333; }
header { background:#ff6f00; color:white; padding:20px; text-align:center; }
.container { width:90%; max-width:1100px; margin:30px auto; background:white; padding:25px; border-radius:12px; box-shadow:0 4px 20px rgba(0,0,0,0.1); }
.summary h3 { margin:10px 0; color:#ff6f00; }
.summary ul { padding-left:20px; }
.filter-bar { margin-bottom:20px; display:flex; gap:10px; flex-wrap:wrap; }
.filter-bar input, .filter-bar select { padding:10px; border-radius:6px; border:1px solid #ccc; }
table { width:100%; border-collapse:collapse; margin-top:15px; box-shadow:0 2px 5px rgba(0,0,0,0.05);}
th, td { padding:12px 15px; border:1px solid #ddd; text-align:left; }
th { background:#ff6f00; color:white; cursor:pointer; }
tr:nth-child(even) { background:#f9f9f9; }
.action-btn { padding:5px 10px; border-radius:5px; border:none; cursor:pointer; font-weight:bold; margin-right:5px; }
.edit-btn { background:#3498db; color:white; }
.delete-btn { background:#e74c3c; color:white; }
.approve-btn { background:#2ecc71; color:white; }
.back-link { display:inline-block; margin-top:15px; text-decoration:none; color:#ff6f00; font-weight:bold; }
.back-link:hover { text-decoration:underline; }
input.edit-field { width:80%; padding:4px; font-size:14px; }
</style>
</head>
<body>

<header><h1>Admin | Manage Reviews</h1></header>

<div class="container">
    <div class="summary">
        <h3>Total Reviews: <?php echo $totalReviews; ?></h3>
        <h3>Top-Rated Sitters:</h3>
        <ul>
            <?php while($s=mysqli_fetch_assoc($topSittersResult)): ?>
                <li><?php echo htmlspecialchars($s['sitter_name']); ?> - <?php echo $s['avg_rating']; ?>⭐ (<?php echo $s['total_reviews']; ?> reviews)</li>
            <?php endwhile; ?>
        </ul>
    </div>

    <div class="filter-bar">
        <input type="text" id="filterParent" placeholder="Search by Parent">
        <input type="text" id="filterSitter" placeholder="Search by Sitter">
        <select id="filterRating">
            <option value="">All Ratings</option>
            <option value="5">★★★★★ 5 Stars</option>
            <option value="4">★★★★ 4 Stars</option>
            <option value="3">★★★ 3 Stars</option>
            <option value="2">★★ 2 Stars</option>
            <option value="1">★ 1 Star</option>
        </select>
    </div>

    <table id="reviewsTable">
        <thead>
            <tr>
                <th>Parent Name</th>
                <th>Sitter Name</th>
                <th>Rating</th>
                <th>Comment</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>

    <a href="Admin_Dashboard.php" class="back-link">← Back to Dashboard</a>
</div>

<script>
// Fetch and render reviews
function loadReviews() {
    const parent = document.getElementById('filterParent').value;
    const sitter = document.getElementById('filterSitter').value;
    const rating = document.getElementById('filterRating').value;

    fetch(`report_reviews.php?ajax=1&parent=${encodeURIComponent(parent)}&sitter=${encodeURIComponent(sitter)}&rating=${rating}`)
    .then(res => res.json())
    .then(data => {
        const tbody = document.querySelector('#reviewsTable tbody');
        tbody.innerHTML = '';

        data.forEach(r => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${r.parent_name}</td>
                <td>${r.sitter_name}</td>
                <td>
                    <input type="number" class="edit-field" value="${r.rating}" min="1" max="5" onchange="updateReview(${r.review_id}, this.value)">
                </td>
                <td>
                    <input type="text" class="edit-field" value="${r.comment}" onchange="updateReview(${r.review_id}, null, this.value)">
                </td>
                <td>${r.created_at}</td>
                <td>
                    <button class="approve-btn action-btn" onclick="approveReview(${r.review_id})">Approve</button>
                    <button class="delete-btn action-btn" onclick="deleteReview(${r.review_id})">Delete</button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    });
}

// Inline update review
function updateReview(id, rating=null, comment=null) {
    fetch('update_review.php', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({review_id: id, rating: rating, comment: comment})
    }).then(res => res.json())
      .then(res => { if(res.success) loadReviews(); });
}

// Approve review
function approveReview(id){
    fetch('approve_review.php', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({review_id: id})
    }).then(res => res.json())
      .then(res => { if(res.success) loadReviews(); });
}

// Delete review
function deleteReview(id){
    if(confirm('Are you sure you want to delete this review?')){
        fetch('delete_review.php', {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({review_id: id})
        }).then(res => res.json())
          .then(res => { if(res.success) loadReviews(); });
    }
}

// Filter listeners
document.getElementById('filterParent').addEventListener('input', loadReviews);
document.getElementById('filterSitter').addEventListener('input', loadReviews);
document.getElementById('filterRating').addEventListener('change', loadReviews);

// Initial load
loadReviews();
</script>

<script src="script.js"></script>
</body>
</html>
