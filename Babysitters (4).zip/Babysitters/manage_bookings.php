<?php
session_start();
include('db_connect.php');

// Allow only admin access
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'admin') {
    header('Location: index.php');
    exit;
}

// Handle AJAX update for booking status
if (isset($_POST['update_status'], $_POST['booking_id'])) {
    $booking_id = intval($_POST['booking_id']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    mysqli_query($conn, "UPDATE bookings SET status='$status' WHERE booking_id=$booking_id");
    echo 'success';
    exit;
}

// Handle delete action
if (isset($_GET['action'], $_GET['id']) && $_GET['action'] === 'delete') {
    $booking_id = intval($_GET['id']);
    mysqli_query($conn, "DELETE FROM bookings WHERE booking_id=$booking_id");
    header('Location: manage_bookings.php');
    exit;
}

// Fetch bookings
function fetch_bookings($conn, $filter = []) {
    $where = [];
    if (!empty($filter['parent'])) $where[] = "p.phone LIKE '%".mysqli_real_escape_string($conn,$filter['parent'])."%'";
    if (!empty($filter['sitter'])) $where[] = "s.phone LIKE '%".mysqli_real_escape_string($conn,$filter['sitter'])."%'";
    if (!empty($filter['status'])) $where[] = "b.status='".mysqli_real_escape_string($conn,$filter['status'])."'";

    $sql = "
        SELECT b.booking_id, b.booking_date, b.status,
               p.phone AS parent_phone, p.address AS parent_address,
               s.phone AS sitter_phone, s.location AS sitter_location
        FROM bookings b
        LEFT JOIN parents p ON b.parent_id = p.parent_id
        LEFT JOIN sitters s ON b.sitter_id = s.sitter_id
    ";
    if ($where) $sql .= " WHERE ".implode(' AND ', $where);
    $sql .= " ORDER BY b.booking_date DESC";

    $result = mysqli_query($conn, $sql);
    if (!$result) {
        error_log("MySQL error in fetch_bookings: " . mysqli_error($conn) . " -- SQL: " . $sql);
        return false;
    }
    return $result;
}

// AJAX fetch for table refresh
if (isset($_GET['ajax'])) {
    $filter = [
        'parent' => $_GET['parent'] ?? '',
        'sitter' => $_GET['sitter'] ?? '',
        'status' => $_GET['status'] ?? ''
    ];
    $bookings = fetch_bookings($conn, $filter);
    while($b = mysqli_fetch_assoc($bookings)) {
        $status = $b['status'] ?? 'pending';
        $color = match($status) {
            'pending' => '#f1c40f',
            'approved' => '#27ae60',
            'completed' => '#2980b9',
            'cancelled' => '#e74c3c',
            default => 'white'
        };
        echo "<tr>
            <td>{$b['booking_id']}</td>
            <td>{$b['parent_phone']} ({$b['parent_address']})</td>
            <td>{$b['sitter_phone']} ({$b['sitter_location']})</td>
            <td>{$b['booking_date']}</td>
            <td>
                <select class='status-dropdown' data-id='{$b['booking_id']}' style='background-color:$color;color:white;'>
                    <option value='pending' ".($status=='pending'?'selected':'').">Pending</option>
                    <option value='approved' ".($status=='approved'?'selected':'').">Approved</option>
                    <option value='completed' ".($status=='completed'?'selected':'').">Completed</option>
                    <option value='cancelled' ".($status=='cancelled'?'selected':'').">Cancelled</option>
                </select>
            </td>
            <td>
                <a href='?action=delete&id={$b['booking_id']}' class='action-btn delete' onclick=\"return confirm('Delete this booking?')\">Delete</a>
            </td>
        </tr>";
    }
    exit;
}

// Initial load
$bookings = fetch_bookings($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Bookings | ChaguaSitter Admin</title>
<style>
:root { --primary: #e67e22; --bg: #fff; --text: #222; --card-bg: #fff; --table-border: #ddd; }
body.dark { --bg: #121212; --text: #f1f1f1; --card-bg: #1e1e1e; --table-border: #333; }
body { font-family: 'Poppins', sans-serif; margin:0; background: var(--bg); color: var(--text); transition:0.4s; }
header { background: var(--card-bg); padding:20px; display:flex; justify-content:space-between; align-items:center; border-bottom:3px solid var(--primary); position:sticky; top:0; z-index:999; }
h1 { color: var(--primary); margin:0; font-size:1.8em; }
nav a { margin:0 10px; text-decoration:none; color: var(--text); font-weight:500; }
nav a:hover { color: var(--primary); }
.theme-toggle { background: var(--primary); color:white; border:none; padding:8px 14px; border-radius:6px; cursor:pointer; font-weight:bold; }
.container { background: var(--card-bg); margin:40px auto; padding:25px; width:90%; border-radius:20px; box-shadow:0 4px 10px rgba(0,0,0,0.1); }
h2 { color: var(--primary); margin-bottom:20px; }
table { width:100%; border-collapse:collapse; box-shadow:0 0 5px rgba(0,0,0,0.1); }
th, td { padding:12px; border:1px solid var(--table-border); text-align:left; }
th { background: var(--primary); color:white; }
tr:nth-child(even) { background-color: rgba(0,0,0,0.03); }
.status-dropdown { padding:6px 10px; border-radius:6px; border:none; font-weight:bold; cursor:pointer; }
.action-btn { padding:6px 12px; margin-right:5px; border:none; border-radius:5px; cursor:pointer; font-weight:bold; color:white; text-decoration:none; display:inline-block;}
.delete { background:#95a5a6; }
.action-btn:hover { opacity:0.85; }
.filter-bar { margin-bottom:20px; display:flex; flex-wrap:wrap; gap:15px; }
.filter-bar input, .filter-bar select, .filter-bar button { padding:8px; border-radius:6px; border:1px solid #ccc; cursor:pointer; }
</style>
</head>
<body>

<header>
  <h1>Manage Bookings</h1>
  <nav>
    <a href="Admin_Dashboard.php">Dashboard</a>
    <a href="manage_parents.php">Parents</a>
    <a href="manage_sitters.php">Sitters</a>
    <a href="reports_reviews.php">Reports</a>
    <a href="logout.php">Logout</a>
  </nav>
  <button class="theme-toggle" id="themeToggle">🌙 Dark Mode</button>
</header>

<div class="container">
  <h2>Bookings List</h2>

  <div class="filter-bar">
    <input type="text" id="filterParent" placeholder="Search by Parent">
    <input type="text" id="filterSitter" placeholder="Search by Sitter">
    <select id="filterStatus">
      <option value="">All Status</option>
      <option value="pending">Pending</option>
      <option value="approved">Approved</option>
      <option value="completed">Completed</option>
      <option value="cancelled">Cancelled</option>
    </select>
    <button id="applyFilter">Filter</button>
  </div>

  <table id="bookingsTable">
    <tr>
      <th>ID</th>
      <th>Parent</th>
      <th>Sitter</th>
      <th>Date</th>
      <th>Status</th>
      <th>Actions</th>
    </tr>
    <?php while($b = mysqli_fetch_assoc($bookings)):
        $status = $b['status'] ?? 'pending';
        $color = match($status) {
            'pending'=>'#f1c40f','approved'=>'#27ae60','completed'=>'#2980b9','cancelled'=>'#e74c3c', default=>'white'
        };
    ?>
      <tr>
        <td><?= $b['booking_id'] ?></td>
        <td><?= $b['parent_phone'] ?> (<?= $b['parent_address'] ?>)</td>
        <td><?= $b['sitter_phone'] ?> (<?= $b['sitter_location'] ?>)</td>
        <td><?= $b['booking_date'] ?></td>
        <td>
          <select class='status-dropdown' data-id='<?= $b['booking_id'] ?>' style="background-color:<?= $color ?>; color:white;">
            <option value='pending' <?= $status=='pending'?'selected':'' ?>>Pending</option>
            <option value='approved' <?= $status=='approved'?'selected':'' ?>>Approved</option>
            <option value='completed' <?= $status=='completed'?'selected':'' ?>>Completed</option>
            <option value='cancelled' <?= $status=='cancelled'?'selected':'' ?>>Cancelled</option>
          </select>
        </td>
        <td>
          <a href='?action=delete&id=<?= $b['booking_id'] ?>' class='action-btn delete' onclick="return confirm('Delete this booking?')">Delete</a>
        </td>
      </tr>
    <?php endwhile; ?>
  </table>
</div>

<script>
const toggleBtn = document.getElementById('themeToggle');
const body = document.body;
if(localStorage.getItem('theme')==='dark'){body.classList.add('dark'); toggleBtn.textContent='☀️ Light Mode';}
toggleBtn.addEventListener('click',()=>{
  body.classList.toggle('dark');
  const dark = body.classList.contains('dark');
  toggleBtn.textContent = dark?'☀️ Light Mode':'🌙 Dark Mode';
  localStorage.setItem('theme', dark?'dark':'light');
});

// Update booking status
function updateStatus(bookingId,status){
    fetch('manage_bookings.php',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:`update_status=1&booking_id=${bookingId}&status=${status}`
    }).then(res=>res.text()).then(data=>{if(data==='success')console.log(`Booking ${bookingId} updated to ${status}`);});
}

// Change dropdown color
function updateDropdownColor(dropdown){
    let color='';
    switch(dropdown.value){
        case 'pending': color='#f1c40f'; break;
        case 'approved': color='#27ae60'; break;
        case 'completed': color='#2980b9'; break;
        case 'cancelled': color='#e74c3c'; break;
        default: color='white';
    }
    dropdown.style.backgroundColor=color;
    dropdown.style.color='white';
}

function attachStatusEvents(){
    document.querySelectorAll('.status-dropdown').forEach(dropdown=>{
        updateDropdownColor(dropdown);
        dropdown.addEventListener('change',e=>{
            const bookingId = e.target.getAttribute('data-id');
            updateStatus(bookingId,e.target.value);
            updateDropdownColor(dropdown);
        });
    });
}
attachStatusEvents();

// AJAX filter
function loadBookings(){
    const parent=document.getElementById('filterParent').value;
    const sitter=document.getElementById('filterSitter').value;
    const status=document.getElementById('filterStatus').value;

    fetch(`manage_bookings.php?ajax=1&parent=${parent}&sitter=${sitter}&status=${status}`)
    .then(res=>res.text())
    .then(html=>{
        document.getElementById('bookingsTable').innerHTML=`
            <tr>
              <th>ID</th>
              <th>Parent</th>
              <th>Sitter</th>
              <th>Date</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>`+html;
        attachStatusEvents();
    });
}
document.getElementById('applyFilter').addEventListener('click',loadBookings);
</script>
<script src="script.js"></script>
</body>
</html>
