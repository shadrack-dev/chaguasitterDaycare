<?php
header("Content-Type: application/json");
include "db_connect.php";
include "config.php";
include "jwt_functions.php";
$data = json_decode(file_get_contents("php://input"), true);

$booking_id      = $data['booking_id'];
$parent_id       = $data['parent_id'];
$sitter_id       = $data['sitter_id'];
$amount          = $data['amount'];
$payment_method  = $data['payment_method'];
$status          = $data['status'];
$transaction_code = $data['transaction_code'];

$sql = "INSERT INTO payments (booking_id, parent_id, sitter_id, amount, payment_method, status, transaction_code)
        VALUES (?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("iiidsss", $booking_id, $parent_id, $sitter_id, $amount, $payment_method, $status, $transaction_code);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Payment created successfully"]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to create payment"]);
}
?>
